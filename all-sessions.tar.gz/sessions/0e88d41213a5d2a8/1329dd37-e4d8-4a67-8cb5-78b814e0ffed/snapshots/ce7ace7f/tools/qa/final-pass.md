# QA final pass (10:46-11:00 UTC, live repo at 8c6780d plus uncommitted ARTIST edits)

## Writer drafts: corrections
Everything else in tools/writer/README.md and index-comment.txt matches the code: all keys (input.js, app.js
OVERLAY_KEYS and handleKey), every TUNING number, data/*.js, the upgrades, the coach (LESSON_DISHES = 2), the
file names, port 8080 and the shots.js frames.

1. README screenshots table, critic row: "King Tide during a Spring Tide rush" is wrong. shots.js freezes at frame
   7489 = 124.8 s. The rush that starts at 96 s ends at 120 s, and the next one is at 146 s (inRush false in Node).
   Use: "King Tide late in service, Madame Mantis waiting with her live rating at 4.5 stars".
2. README features: "8 recipes, 10 ingredients, 5 stations" contradicts "four kinds of station". Pot 2 is locked
   until the Second Bubble Pot is bought. Use: "8 recipes, 10 ingredients, 4 kinds of station".
3. README: "`?autoplay&speed=8` lets the scripted chef play a normal night" leaves out that the page still opens on
   the title. Use: "With `?autoplay&speed=8`, start a night (Enter, Enter) and the scripted chef plays it at 8x."
4. Optional: the moon row can add "during a Spring Tide rush" (138.5 s, inside the 128-152 s rush).
   `node serve.ts` needs Node 22.18 or newer (type stripping).
5. Size: index-comment.txt is 2793 B, so index.html grows from 1385 B to 3416 B. With the order below, that pushes the
   cut 956 B before the end of render/customers.js. Trim the comment by about 1 KB (to about 1.75 KB) to keep
   customers.js whole.

## Dossier order (only app.js imports change; main.js stays as it is)
app.js lines 7-19 become:

    import { createNight, dispatch, inRush, nightSummary, stepNight } from './state.js';
    import { NIGHTS } from './data/nights.js';
    import { buyUpgrade, recordNight, saveCampaign, UPGRADES } from './campaign.js';
    import { playEvent, setMuted, unlockAudio, updateMusic } from './audio.js';
    import { actionForArea, actionForKey, hitTest, nightHitAreas } from './input.js';
    import { chefThink } from './autochef.js';
    import { streakMultiplier } from './scoring.js';
    import { drawArmSlots, drawBanners, drawChecklist, drawHud, drawKeyHints, drawOrderBoard, drawTideGauge, drawToasts } from './render/ui.js';
    import { createArmView, drawOctavia, updateArmView } from './render/octopus.js';
    import { drawAtmosphere, drawBins, drawStationOverlays, drawClamPlate, drawCounter, drawPass, drawStations, drawTrash, drawWall } from './render/scene.js';
    import { ambient, createEffects, drawEffects, spawnFromEvents, updateEffects } from './render/effects.js';
    import { drawHelp, drawMap, drawPause, drawResults, drawSettings, drawShop, drawTitle } from './render/screens.js';
    import { panel, text } from './render/draw.js';

Order and cut (dossier-report on tools/qa/order-test, live files at 10:53):
- A (above): all 20 logic files, then ui.js 135113, draw.js 141948, customers.js 162765 (whole). The cut falls 1075 B
  into food.js, and octopus.js is never seen.
- B (octopus.js first): octopus.js, draw.js and food.js whole, a partial light.js, and ui.js and customers.js
  never seen.
- Now (live order): octopus.js, draw.js, food.js and light.js whole, cut inside scene.js, and ui.js, customers.js,
  autochef.js never seen.
- octopus.js cannot come before food.js (octopus.js imports food.js) without editing ui.js. With 64 KB left after
  the logic files, ui.js, customers.js and octopus.js (78 KB) do not all fit.
- Only main.js has top-level side effects. The other modules create only empty Maps and Sets, and the import graph
  has no cycles, so the order is safe. The copy loads in Chrome with 0 errors and 0 offsite requests: title, keys,
  autoplay to results in 9 s at 20x, and the cover/moon/critic/results scenes.
