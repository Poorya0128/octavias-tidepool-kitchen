# Octavia v2 team brief (shared by every agent)

Repo: /projects/sandbox/octavias-tidepool-kitchen (branch v2-living-reef). The game is plain ES modules
under game/src, Canvas 2D + WebAudio, logical canvas 1280x800, fixed step 1/60 s. No libraries, no
image/sound files, no network requests, no build step. Do NOT touch vendor/, main.ts, LICENSE,
screenshots/, shots.json, README.md, game/index.html (the lead owns those). Do NOT run git commit,
git checkout, git stash, git reset or any branch command: the lead commits. `git diff` is fine.

## How the judge works (why we do this)
An AI judge compares entries pairwise using 3-4 screenshots and the game source text (index.html, then
modules in import order, cut at 160 KB). So: screenshots must look stunning and clearly show a kitchen,
an order board, ingredients on the counter, a dish mid-preparation, a timer and a plate ready to serve.
Code must stay clean, readable, documented (one short JSDoc line per export, like the existing code)
and lean (no dead code, no giant data tables).

## File ownership (edit ONLY your own files; read anything)
- ENGINEER: state.js, stations.js, orders.js, arms.js, scoring.js, campaign.js, rng.js, autochef.js,
  input.js, audio.js, app.js, main.js, shots.js, data/*.js
- DESIGNER: render/octopus.js, render/customers.js, render/ui.js, render/screens.js
- ARTIST: render/scene.js, render/food.js, render/effects.js, and any NEW file under render/ it creates
- render/draw.js and config.js: shared. Only ADD new exports/keys; never change or remove existing ones.
  Re-read the file right before editing it and keep the edit small (another agent may be editing it).
- QA: no game files at all. Works in /projects/sandbox/tools/qa.

## Contracts already wired by the lead (rely on them, keep their signatures)
- `state.ink = { meter: 0..1, active: bool, endsAt: seconds, uses: n }` (created in createNight).
  ENGINEER implements Ink Burst. DESIGNER draws the ink meter/button inside `LAYOUT.ink`
  ({x:12,y:538,w:104,h:110}, the free counter corner under the ARMS panel), key `I`.
  ARTIST draws the ink cloud effect on the `inkBurst` event.
- `state.moments = { [eventType]: lastTimeSeconds }`: ENGINEER keeps it updated for every event type,
  so renderers can react (e.g. `state.time - (state.moments.cookPerfect ?? -99) < 1.5`).
- `state.speech = [{ ticketId, customerId, kind: 'arrive'|'wait'|'happy'|'angry', text, at }]`,
  newest last, at most 6 kept. ENGINEER fills it from voice lines in data/customers.js
  (`CUSTOMERS[id].lines = { arrive: [], wait: [], happy: [], angry: [] }`). DESIGNER shows bubbles.
- New events from ENGINEER (push into state.events like the others): `cookPerfect` {station, slot, x, y}
  when food enters its PERFECT window, `cookBurnt` {station, slot, x, y} when it burns,
  `inkBurst` {x, y} when Ink Burst starts, `inkReady` when the meter fills.
  Coordinates: use SLOT_TARGETS from config.js.
- `drawWindowDiners(ctx, state, t, rect)` exported from render/customers.js (DESIGNER fills it in).
  ARTIST calls it from drawPass in render/scene.js, inside the Current Window, before the plates.
- `drawAtmosphere(ctx, state, t, calm)` exported from render/scene.js (ARTIST fills it in). app.js
  already calls it after drawBins and before drawOrderBoard.
- Renderers must never crash when a field is missing: read new fields with `?.` and `??`.
- Renderers must not consume `state.rng` (logic determinism). Math.random is fine for visuals.

## Always keep the game loadable
Other agents test at the same time. Make small edits and run `node --check <file>` after every edit.
A broken import breaks everyone's screenshots.

## Seeing the game (headless Chrome via the Playwright tool)
Load the tool with load_resource id `power::playwright::tool::playwright::browser_run_code_unsafe`,
then call it through tool_call. Always open YOUR OWN page and close it (other agents share the browser).
`URL` is not defined in that sandbox; use string slicing. Template (change the query and file name):

async (page) => {
  const ROOT = '/projects/sandbox/octavias-tidepool-kitchen/game';
  const p = await page.context().newPage();
  await p.setViewportSize({ width: 1280, height: 800 });
  const errors = []; const offsite = [];
  p.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  p.on('pageerror', (e) => errors.push(String(e)));
  p.on('request', (r) => { if (!r.url().startsWith('http://game.test/')) offsite.push(r.url()); });
  await p.route('http://game.test/**', async (route) => {
    let path = route.request().url().slice('http://game.test'.length).split('?')[0].split('#')[0];
    if (path.endsWith('/')) path += 'index.html';
    try { await route.fulfill({ path: ROOT + path, headers: { 'cache-control': 'no-store' } }); }
    catch (e) { await route.fulfill({ status: 404, body: 'not found' }); }
  });
  await p.goto('http://game.test/index.html?scene=cover&seed=7');
  await p.waitForFunction(() => document.body.dataset.ready, null, { timeout: 60000 });
  await p.waitForTimeout(400);
  await p.screenshot({ path: '/projects/sandbox/tools/shots-YOURROLE/NAME.jpg', type: 'jpeg', quality: 85 });
  await p.close();
  return JSON.stringify({ errors, offsite });
}

Then view the image with read_file. Useful queries: `?scene=cover&seed=7` (Storm Tide kitchen),
`?scene=critic&seed=11` (King Tide), `?scene=map&seed=7`, `?scene=results&seed=7`, plain index.html
(title), `?autoplay&speed=8` (the scripted chef plays live; wait a few seconds then shoot).
Keys can be pressed with `await p.keyboard.press('Enter')`, clicks with `await p.mouse.click(x, y)`.

## Headless logic check (Node 22 imports the modules directly)
node /projects/sandbox/tools/sim-probe.mjs   -> plays all 5 nights with the scripted chef in ~0.2 s.
