// Coach probe: plays night 1 pressing only the keys the first-shift coach asks for, and prints
// every hint change. Checks that the coach reaches its goodbye (2 dishes served) and retires.
//   node /projects/sandbox/tools/coach-probe.mjs [seed] [reaction seconds]
const SRC = '/projects/sandbox/octavias-tidepool-kitchen/game/src/';
const { createNight, dispatch, stepNight } = await import(SRC + 'state.js');
const { actionForKey } = await import(SRC + 'input.js');
const seed = Number(process.argv[2] ?? 7);
const react = Number(process.argv[3] ?? 0.6);
const s = createNight({ nightIndex: 0, seed, coach: true });
let last = '';
let wait = 0;
let done = null;
const KEY = { Space: ' ', Bksp: 'Backspace' };
while (!s.over && s.time < 120) {
  stepNight(s, 1 / 60);
  for (const e of s.events) if (e.type === 'coachDone') done = s.time;
  s.events.length = 0;
  const c = s.coach;
  const line = c ? `${c.step}/${c.total} [${c.key ?? '-'}] ${c.text} @${c.target ? `${Math.round(c.target.x)},${Math.round(c.target.y)}` : 'none'}` : 'null';
  if (line !== last) {
    console.log(s.time.toFixed(2).padStart(6), line);
    last = line;
    wait = react;
  }
  wait -= 1 / 60;
  if (c && c.key && !/^Wait|chopping/.test(c.text) && wait <= 0) {
    const action = actionForKey(s, KEY[c.key] ?? c.key);
    const res = dispatch(s, action);
    if (!res.ok) console.log('       !', c.key, res.reason);
    wait = react;
  }
}
console.log(`served ${s.stats.served}, coaching ${s.coaching}, coachDone at ${done?.toFixed(2)}, toasts ${s.toasts.map((t) => t.text).join(' | ')}`);
process.exit(done !== null && s.stats.served >= 2 ? 0 : 1);
