async (page) => {
  // QA scene lint: opens the title, the map and the screenshot scenes in its own browser context and, per screen,
  // saves OUT/lint-<name>.jpg and lists text problems with the file:line that drew them: OVERLAP (two visible texts
  // cross), SQUISH (maxWidth compresses text below 85%), TINY (< 11 px), OFFCANVAS. It also reports fps and the
  // canvas calls per frame (gradients, fills, strokes, arcs, drawImage, new canvases). The page renders on CPU here.
  // Run with browser_run_code_unsafe, this whole file as `code`. Returns JSON {errors, offsite, screens}.
  const ROOT = '/projects/sandbox/octavias-tidepool-kitchen';
  const OUT = '/projects/sandbox/tools/qa';
  const ORIGIN = 'http://game.test';
  const SCREENS = [['title', ''], ['map', 'scene=map&seed=7'], ['results', 'scene=results&seed=7'],
    ['cover', 'scene=cover&seed=7'], ['moon', 'scene=moon&seed=7'], ['critic', 'scene=critic&seed=11']];
  const errors = [];
  const offsite = [];
  const browser = page.context().browser();
  const bctx = browser ? await browser.newContext({ viewport: { width: 1280, height: 800 } }) : null;
  const p = bctx ? await bctx.newPage() : await page.context().newPage();
  await p.setViewportSize({ width: 1280, height: 800 });
  p.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  p.on('pageerror', (e) => errors.push(String(e)));
  p.on('request', (r) => { if (!r.url().startsWith(`${ORIGIN}/`)) offsite.push(r.url()); });
  await p.route(`${ORIGIN}/**`, async (route) => {
    let path = route.request().url().slice(ORIGIN.length).split('?')[0].split('#')[0];
    if (path.endsWith('/')) path += 'index.html';
    try { await route.fulfill({ path: `${ROOT}/game${path}`, headers: { 'cache-control': 'no-store' } }); }
    catch (e) { await route.fulfill({ status: 404, body: 'not found' }); }
  });
  await p.addInitScript(() => {
    localStorage.clear();
    const P = CanvasRenderingContext2D.prototype;
    const C = { lin: 0, rad: 0, canvas: 0, fill: 0, stroke: 0, arc: 0, drawImage: 0, fillText: 0 };
    for (const [name, key] of [['createLinearGradient', 'lin'], ['createRadialGradient', 'rad'], ['fill', 'fill'], ['stroke', 'stroke'], ['arc', 'arc'], ['drawImage', 'drawImage']]) {
      const f = P[name];
      P[name] = function (...a) { C[key]++; return f.apply(this, a); };
    }
    const ce = Document.prototype.createElement;
    Document.prototype.createElement = function (tag, ...r) { if (String(tag).toLowerCase() === 'canvas') C.canvas++; return ce.call(this, tag, ...r); };
    let cur = null;
    let want = false;
    const resolvers = [];
    const where = () => {
      const f = String(new Error().stack).split('\n').map((l) => (l.match(/\/src\/([\w/.-]+):(\d+)/) || []).slice(1).join(':')).filter(Boolean);
      return f.find((s) => !s.startsWith('render/draw.js')) || f[0] || '?';
    };
    const fill = P.fillText;
    P.fillText = function (t, x, y, ...rest) {
      C.fillText++;
      const s = String(t);
      if (cur && s.trim()) {
        const m = this.getTransform();
        const base = this.canvas.width / 1280;
        const size = Number((this.font.match(/([\d.]+)px/) || [0, 12])[1]);
        let w = this.measureText(s).width;
        let squish = 1;
        if (rest[0] !== undefined && w > rest[0]) { squish = rest[0] / w; w = rest[0]; }
        const al = this.textAlign;
        const bl = this.textBaseline;
        const x0 = al === 'center' ? x - w / 2 : al === 'right' || al === 'end' ? x - w : x;
        const top = bl === 'top' ? y : bl === 'middle' ? y - size / 2 : bl === 'bottom' || bl === 'ideographic' ? y - size : y - size * 0.8;
        const pts = [[x0, top], [x0 + w, top], [x0, top + size], [x0 + w, top + size]].map(([px, py]) => [(m.a * px + m.c * py + m.e) / base, (m.b * px + m.d * py + m.f) / base]);
        const xs = pts.map((q) => q[0]);
        const ys = pts.map((q) => q[1]);
        cur.push({ t: s.slice(0, 48), x0: Math.round(Math.min(...xs)), y0: Math.round(Math.min(...ys)), x1: Math.round(Math.max(...xs)), y1: Math.round(Math.max(...ys)),
          px: Math.round((size * Math.hypot(m.a, m.b) * 10) / base) / 10, a: this.globalAlpha, squish: Math.round(squish * 100) / 100, at: where() });
      }
      return fill.call(this, t, x, y, ...rest);
    };
    const frames = [];
    const raf = window.requestAnimationFrame.bind(window);
    window.requestAnimationFrame = (cb) => raf((ts) => {
      if (want) cur = [];
      const before = { ...C };
      cb(ts);
      const d = {};
      for (const k in C) d[k] = C[k] - before[k];
      frames.push({ ts, d });
      if (frames.length > 400) frames.shift();
      if (cur) { const list = cur; cur = null; want = false; resolvers.splice(0).forEach((r) => r(list)); }
    });
    window.__qaFrames = frames;
    window.__qaSnap = () => new Promise((res) => { resolvers.push(res); want = true; });
  });
  /** Text problems in one frame's list of text boxes. */
  const analyse = (list) => {
    const issues = [];
    const vis = list.filter((b) => b.a > 0.25);
    for (const b of vis) {
      if (b.x0 < -2 || b.y0 < -2 || b.x1 > 1282 || b.y1 > 802) issues.push(`OFFCANVAS "${b.t}" [${b.x0},${b.y0}-${b.x1},${b.y1}] ${b.at}`);
      if (b.squish < 0.85) issues.push(`SQUISH ${Math.round(b.squish * 100)}% "${b.t}" @${b.x0},${b.y0} ${b.at}`);
      if (b.px < 11) issues.push(`TINY ${b.px}px "${b.t}" @${b.x0},${b.y0} ${b.at}`);
    }
    for (let i = 0; i < vis.length; i++) {
      for (let j = i + 1; j < vis.length; j++) {
        const A = vis[i];
        const B = vis[j];
        if (A.t === B.t && Math.abs(A.x0 - B.x0) < 5 && Math.abs(A.y0 - B.y0) < 5) continue;
        const ix = Math.min(A.x1, B.x1) - Math.max(A.x0, B.x0);
        const iy = Math.min(A.y1, B.y1) - Math.max(A.y0, B.y0);
        if (ix <= 1 || iy <= 1) continue;
        const small = Math.min((A.x1 - A.x0) * (A.y1 - A.y0), (B.x1 - B.x0) * (B.y1 - B.y0));
        if (ix * iy > 0.12 * small) issues.push(`OVERLAP "${A.t}" (${A.at}) x "${B.t}" (${B.at}) @${Math.max(A.x0, B.x0)},${Math.max(A.y0, B.y0)}`);
      }
    }
    return [...new Set(issues)];
  };
  const screens = {};
  for (const [name, query] of SCREENS) {
    try {
      await p.goto(`${ORIGIN}/index.html${query ? `?${query}` : ''}`);
      await p.waitForFunction(() => document.body.dataset.ready, null, { timeout: 60000 });
      await p.waitForTimeout(1500);
      const list = await p.evaluate(() => window.__qaSnap());
      await p.screenshot({ path: `${OUT}/lint-${name}.jpg`, type: 'jpeg', quality: 82 });
      const perf = await p.evaluate(() => {
        const fr = window.__qaFrames.slice(-60);
        const per = {};
        for (const k of Object.keys(fr[0].d)) per[k] = Math.round(fr.reduce((a, f) => a + f.d[k], 0) / fr.length);
        return { fps: Math.round((10000 * (fr.length - 1)) / (fr[fr.length - 1].ts - fr[0].ts)) / 10, perFrame: per };
      });
      screens[name] = { texts: list.length, ...perf, issues: analyse(list) };
    } catch (e) {
      screens[name] = { error: String(e).split('\n')[0] };
    }
  }
  await p.close();
  if (bctx) await bctx.close();
  return JSON.stringify({ root: ROOT, errors, offsite, screens }, null, 1);
}
