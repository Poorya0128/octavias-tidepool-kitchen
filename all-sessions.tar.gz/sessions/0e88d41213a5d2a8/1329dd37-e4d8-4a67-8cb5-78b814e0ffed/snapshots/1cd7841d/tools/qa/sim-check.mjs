#!/usr/bin/env node
// QA: plays every night with the scripted chef across seeds and cadences and checks the rules hold.
//   node /projects/sandbox/tools/qa/sim-check.mjs [repoRoot] [--seeds=1,7,11,29] [--cadences=0.35,0.5,0.8,1.2]
// repoRoot defaults to the live repo. Exit code 1 on any failure; WARN lines never fail the run.
import { pathToFileURL } from 'node:url';
import { join, resolve } from 'node:path';
import { existsSync } from 'node:fs';

const args = process.argv.slice(2);
const opt = (name, def) => (args.find((a) => a.startsWith(`--${name}=`)) ?? `=${def}`).split('=')[1].split(',').map(Number);
const repo = resolve(args.find((a) => !a.startsWith('--')) ?? '/projects/sandbox/octavias-tidepool-kitchen');
const SEEDS = opt('seeds', '1,7,11,29');
const CADENCES = opt('cadences', '0.35,0.5,0.8,1.2');
const ALL_UPGRADES = { secondPot: true, quickArms: true, calmingCoral: true, autoStir: true, biggerPlate: true };
const SPEECH_KINDS = new Set(['arrive', 'wait', 'happy', 'angry']);
const CHECK_EVERY = 0.5; // seconds of night between invariant checks

const src = join(repo, 'game/src');
if (!existsSync(join(src, 'state.js'))) {
  console.error(`sim-check: no game/src/state.js under ${repo}`);
  process.exit(2);
}
const load = (rel) => import(pathToFileURL(join(src, rel)).href);
const { createNight, nightSummary } = await load('state.js');
const { createAutoChef, simulateNight } = await load('autochef.js');
const { NIGHTS } = await load('data/nights.js');
const { LAYOUT, STEP = 1 / 60 } = await load('config.js');

const failures = [];
const warnings = new Set();
const reported = new Set(); // live-check failures already reported, once per night run and kind
const fail = (where, msg) => failures.push(`${where}: ${msg}`);
const finite = (v) => typeof v === 'number' && Number.isFinite(v);

/** Paths of every NaN number inside a plain-data value (functions and the rng skipped). */
function nanPaths(value, path = 'state', out = [], seen = new Set()) {
  if (typeof value === 'number') {
    if (Number.isNaN(value)) out.push(path);
  } else if (value && typeof value === 'object' && !seen.has(value)) {
    seen.add(value);
    for (const [k, v] of Object.entries(value)) if (k !== 'rng' && typeof v !== 'function') nanPaths(v, `${path}.${k}`, out, seen);
  }
  return out;
}

/** Invariants that must hold at any moment of a night (new v2 fields only when present). */
function checkLive(state, where) {
  const bad = [];
  if (!finite(state.coins) || state.coins < 0) bad.push(`coins=${state.coins}`);
  for (const [k, v] of Object.entries(state.stats ?? {})) if (!finite(v)) bad.push(`stats.${k}=${v}`);
  if (state.ink !== undefined) {
    const m = state.ink?.meter;
    if (!finite(m) || m < 0 || m > 1) bad.push(`ink.meter=${m}`);
    if (typeof state.ink?.active !== 'boolean') bad.push(`ink.active=${state.ink?.active}`);
    if (!finite(state.ink?.uses ?? 0) || !finite(state.ink?.endsAt ?? 0)) bad.push('ink.uses/endsAt not finite');
  }
  if (state.speech !== undefined) {
    if (!Array.isArray(state.speech) || state.speech.length > 6) bad.push(`speech.length=${state.speech?.length}`);
    for (const s of state.speech ?? []) {
      if (!SPEECH_KINDS.has(s?.kind) || typeof s?.text !== 'string' || !s.text || !finite(s?.at)) bad.push(`bad speech ${JSON.stringify(s)}`);
    }
  }
  if (state.moments !== undefined) {
    for (const [k, v] of Object.entries(state.moments ?? {})) if (!finite(v)) bad.push(`moments.${k}=${v}`);
  }
  for (const b of new Set(bad)) {
    const key = `${where}|${b.replace(/[-\d.]+|NaN|Infinity/g, '#')}`;
    if (!reported.has(key)) fail(where, `first at t=${state.time.toFixed(2)}: ${b}`);
    reported.add(key);
  }
  return bad.length === 0;
}

/** Records every event of a night (simulateNight clears the list each step) and the recipe of each serve. */
function tapEvents(state, log) {
  const tickets = new Map();
  const events = [];
  events.push = function push(...items) {
    for (const e of items) {
      log.types[e?.type] = (log.types[e?.type] ?? 0) + 1;
      if (e?.type === 'spawn') tickets.set(e.ticket, state.tickets.find((t) => t.id === e.ticket));
      if (e?.type === 'serve') {
        const recipe = e.recipe ?? e.recipeId ?? tickets.get(e.ticket)?.recipeId;
        if (recipe) log.served[recipe] = (log.served[recipe] ?? 0) + 1;
      }
    }
    return Array.prototype.push.apply(this, items);
  };
  state.events = events;
  return events;
}

/** Plays one night; returns its summary plus what the checks saw. */
function playNight(nightIndex, seed, cadence, upgrades) {
  const where = `night ${nightIndex + 1} seed ${seed} cad ${cadence}${upgrades === ALL_UPGRADES ? ' +up' : ''}`;
  const log = { types: {}, served: {}, maxTickets: 0 };
  let state;
  try {
    state = createNight({ nightIndex, upgrades, seed });
    const cfg = state.cfg;
    const chef = createAutoChef({ cadence, focus: 2 });
    let events = tapEvents(state, log);
    for (let until = CHECK_EVERY; !state.over; until += CHECK_EVERY) {
      if (until > cfg.duration + 5) { fail(where, `night still running at t=${state.time.toFixed(2)}`); break; }
      simulateNight(state, chef, until);
      if (state.events !== events) { warnings.add('state.events was replaced: serve tracking re-attached'); events = tapEvents(state, log); }
      log.maxTickets = Math.max(log.maxTickets, state.tickets.length);
      checkLive(state, where);
    }
    if (!state.over) fail(where, 'night never ended');
    if (!(state.time >= cfg.duration - 1e-9 && state.time < cfg.duration + STEP + 1e-6)) fail(where, `ended at t=${state.time} not ${cfg.duration}`);
    const s = nightSummary(state);
    if (!finite(s.coins) || s.coins < 0) fail(where, `summary coins=${s.coins}`);
    if (!Number.isInteger(s.stars) || s.stars < 0 || s.stars > 3) fail(where, `stars=${s.stars}`);
    for (const [k, v] of Object.entries(s)) if (typeof v === 'number' && !Number.isFinite(v)) fail(where, `summary.${k}=${v}`);
    if (s.critic !== null && s.critic !== undefined && (!finite(s.critic) || s.critic < 1 || s.critic > 5)) fail(where, `critic=${s.critic}`);
    const nans = nanPaths(state);
    if (nans.length) fail(where, `NaN at ${nans.slice(0, 4).join(', ')}`);
    return { ok: true, s, log };
  } catch (err) {
    fail(where, `exception at t=${state?.time?.toFixed?.(2)}: ${err?.stack?.split('\n').slice(0, 3).join(' | ') ?? err}`);
    return { ok: false, s: null, log };
  }
}

const t0 = performance.now();
if (NIGHTS.length !== 5) fail('data', `NIGHTS has ${NIGHTS.length} nights, expected 5`);
const rows = [];
const coverage = NIGHTS.map(() => ({}));
const eventTypes = {};
const configs = [...CADENCES.map((c) => [c, {}]), [0.5, ALL_UPGRADES]];
const overflow = NIGHTS.map(() => 0);
for (let n = 0; n < NIGHTS.length; n++) {
  for (const [cadence, upgrades] of configs) {
    const runs = SEEDS.map((seed) => playNight(n, seed, cadence, upgrades));
    const okRuns = runs.filter((r) => r.ok);
    for (const r of runs) {
      for (const [id, k] of Object.entries(r.log.served)) coverage[n][id] = (coverage[n][id] ?? 0) + k;
      for (const [type, k] of Object.entries(r.log.types)) eventTypes[type] = (eventTypes[type] ?? 0) + k;
    }
    const sum = (f) => okRuns.reduce((a, r) => a + f(r.s), 0);
    const coins = okRuns.map((r) => r.s.coins);
    const maxTk = Math.max(...runs.map((r) => r.log.maxTickets));
    overflow[n] = Math.max(overflow[n], maxTk);
    rows.push([
      `${n + 1} ${NIGHTS[n].name}`, `${cadence}${upgrades === ALL_UPGRADES ? '+up' : ''}`,
      coins.length ? `${Math.min(...coins)}/${Math.round(sum((s) => s.coins) / okRuns.length)}/${Math.max(...coins)}` : '-',
      okRuns.map((r) => r.s.stars).join(''), sum((s) => s.served), sum((s) => s.missed), sum((s) => s.perfectCooks), sum((s) => s.burnt),
      maxTk, runs.length === okRuns.length ? 'ok' : 'EXC',
    ]);
  }
  if (overflow[n] > LAYOUT.ticket.max) warnings.add(`night ${n + 1}: up to ${overflow[n]} tickets at once but the board draws ${LAYOUT.ticket.max} (the rest only as "+N")`);
  for (const id of NIGHTS[n].recipes) if (!coverage[n][id]) fail(`night ${n + 1}`, `recipe ${id} never served in ${SEEDS.length} seeds x ${configs.length} configs`);
  if (NIGHTS[n].critic?.length && !coverage[n].platter) fail(`night ${n + 1}`, 'critic platter never served');
}

const head = ['night', 'cadence', 'coins min/avg/max', 'stars', 'served', 'missed', 'perfect', 'burnt', 'maxTk', 'run'];
const widths = head.map((h, i) => Math.max(h.length, ...rows.map((r) => String(r[i]).length)));
const line = (r) => r.map((c, i) => String(c).padEnd(widths[i])).join('  ');
console.log(`sim-check ${repo}  seeds ${SEEDS.join(',')}  (served/missed/perfect/burnt summed over seeds; +up = all upgrades)`);
console.log(line(head));
for (const r of rows) console.log(line(r));
for (let n = 0; n < NIGHTS.length; n++) {
  console.log(`served per recipe, night ${n + 1}: ${Object.entries(coverage[n]).map(([id, k]) => `${id} ${k}`).join(', ')}`);
}
const v2 = ['cookPerfect', 'cookBurnt', 'inkBurst', 'inkReady'].map((t) => `${t} ${eventTypes[t] ?? 0}`).join(', ');
console.log(`events: ${Object.keys(eventTypes).length} types; v2 events: ${v2}`);
for (const w of warnings) console.log(`WARN ${w}`);
for (const f of failures.slice(0, 40)) console.log(`FAIL ${f}`);
if (failures.length > 40) console.log(`FAIL ... and ${failures.length - 40} more`);
console.log(`${failures.length ? 'FAILED' : 'PASSED'}: ${rows.length * SEEDS.length} nights in ${Math.round(performance.now() - t0)} ms, ${failures.length} failures, ${warnings.size} warnings`);
process.exit(failures.length ? 1 : 0);
