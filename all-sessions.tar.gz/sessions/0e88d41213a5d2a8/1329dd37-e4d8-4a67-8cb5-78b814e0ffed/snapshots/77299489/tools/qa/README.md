# QA tools for Octavia's Tidepool Kitchen

Node 22 standard library only. Each Node tool takes the repo root as its first argument
(default `/projects/sandbox/octavias-tidepool-kitchen`) and exits 1 on any failure.

| Tool | Command | Checks |
|---|---|---|
| sim-check | `node /projects/sandbox/tools/qa/sim-check.mjs [repo] [--seeds=1,7,11,29] [--cadences=0.35,0.5,0.8,1.2]` | 5 nights x 4 seeds x 4 cadences, plus all upgrades at 0.5 (100 nights, about 1.5 s). Checks: no exception, the night ends at `cfg.duration`, coins finite and >= 0, stars 0-3, every menu recipe (and the critic platter) served at least once, no NaN in stats or state. When present: `ink.meter` in [0,1], `speech.length` <= 6 with valid entries, `moments` values finite. Checked every 0.5 s. Warns when tickets go past the 6 the board draws. |
| compliance | `node /projects/sandbox/tools/qa/compliance.mjs [repo] [--keep]` | Runs `node main.ts` into a temp dir. Checks: dossier.json is `makefun/dossier/v1`, rebuilds byte-identically, images match screenshots/; game/ and screenshots/ copied exactly; vendor kit identical to `27d043c`; MIT LICENSE; 3-4 PNG/JPEG screenshots <= 262144 B (with sizes); network APIs, absolute URLs, `@import`/`url()` and references outside game/; caps; every module parses (`node --check`) and links (named imports exist); keyboard and pointer listeners exist. |
| dossier-report | `node /projects/sandbox/tools/qa/dossier-report.mjs [repo] [--cap=163840]` | The sources in dossier order (kit `readGameTree`/`htmlFacts`/`importOrder`), with file bytes, section bytes and running total. Marks the 163840 B cut, the partial file and the files the judge never sees. Cross-checked against the kit's real `buildDossier` text. |
| browser-check | Playwright `browser_run_code_unsafe`: paste the text of `/projects/sandbox/tools/qa/browser-check.js` as `code` (the tool refused `filename` for this path: "outside allowed roots"). Edit `ROOT` on line 5 to switch repos. | Uses its own browser context. Plays title > map > night 1 > closes the help card > 6 R, 1 Q > cooks, plates and serves the first ticket's dish (the dish is read from the canvas text) > Backspace, Tab > P/P > a 3 s pause with no music burst > H/Esc > M M > mouse click on a bin, then a station > drag milk onto the pot > `?autoplay&speed=20` to results > R right after the night ends > M on results. Screenshots: `qa/bc-NN-*.jpg`. Returns `{errors, offsite, steps, reachedResults}`. |
| scene-lint | Playwright `browser_run_code_unsafe`, the text of `scene-lint.js` as `code`. | Title, map and the results/cover/moon/critic scenes in a fresh context. Saves `qa/lint-<name>.jpg`; lists OVERLAP (two visible texts cross), SQUISH (maxWidth below 85%), TINY (< 11 px) and OFFCANVAS text, each with the `file:line` that drew it (from the call stack); fps and canvas calls per frame. About 15 s. |
| perf-probe | Playwright `browser_run_code_unsafe`, the text of `perf-probe.js` as `code`. | rAF intervals (avg, p95, frames over 20 ms), JS time per frame and canvas calls per frame (gradients, Path2D, fills, strokes, arcs, new canvases, shadowBlur, filter) in a live `?autoplay&speed=1` night (6 s) and the cover scene (3 s), plus 40 cover redraws into a separate canvas. Headless Chrome rasterizes on the CPU, so compare runs with each other. |

## Baseline results (`/projects/sandbox/baseline`, 27d043c)

- sim-check: PASSED, 100 nights, 0 failures. WARN: up to 7 tickets on nights 2-3, 8 on night 4 and 9 on night 5, but the board draws 6.
- compliance: PASSED, 14/14 checks. 27 source files (196250 B), no assets, no network use. The dossier is cut.
- dossier: cut inside `src/render/effects.js` (52 of 138 lines shown). The judge never sees `render/screens.js`, `autochef.js` or `shots.js`.
- live repo at 09:37 UTC: 29 files, 273270 B, 111 KB over the cap. The cut falls inside `render/scene.js` (926 of 1495 lines). The judge never sees `render/customers.js`, `light.js`, `ui.js`, `effects.js`, `screens.js`, `autochef.js` or `shots.js`.
- browser-check: 0 console errors, 0 offsite requests, and the results screen was reached (8.3 s at 20x). Keyboard serve: Pearl Rice Bowl, 0 > 46 coins. Three steps fail by design, because they detect bugs 1, 2 and 6 below.
- browser-check on the live repo at 09:42 UTC (shots in `qa/live/`): same result. 0 errors, 0 offsite, the serve works, and the same three bug steps fail.

## Bugs and UX problems (baseline line numbers; all still present in the live repo at 09:40)

1. HIGH. app.js:213-216 (finishNight 45-50): the results screen takes in-night keys: R (steamer) = Replay, Enter (plate) = Next night. A key still pressed at 0:00 skips the results and the shop. In browser-check, R 150 ms after the night ended restarted the night. Fix: ignore keys on results while `app.t < 1`.
2. HIGH. audio.js:111-123: `updateMusic` returns early while paused, muted or in menus, but never moves `nextNote` forward. On resume it plays every missed beat at once: 16 notes in 300 ms, 12 scheduled in the past, after a 3 s pause. Fix: `if (audio.nextNote < c.currentTime) audio.nextNote = c.currentTime + 0.05;` before the loop.
3. MED. Text overflow the judge can see: campaign.js:14 + screens.js:296. The Bigger Clam Plate text runs under its "160 c" button in 4-results.jpg. ui.js:111-112: ticket names have no maxWidth, and "Tide Pepper Skewer" touches the ticket edge in 1-cover.jpg. Fix: shorter copy, or pass maxWidth.
4. MED. app.js:194: in the pause menu Q = Quit to map, with no confirmation and the night lost. Q is also the Shell Board key, so a stray Esc/P followed by Q abandons the night. Fix: confirm the quit, or put it on a key not used for cooking.
5. MED. Keyboard-only gaps. Upgrades can only be bought with the mouse (screens.js:303; the shop keys at app.js:194 only close it). Reduced motion has no key (screens.js:419). Mouse-only players get no pause, help or mute during a night (app.js:232). Fix: keys 1-5 buy, add a motion key, add a small pause button.
6. MED. app.js:188, 214, screens.js:350: M on results opens the Reef map, but M mutes on every other screen (help card, key hints, settings). Fix: let M mute on results too, and put the map on Esc.
7. MED. state.js:75, orders.js:45, ui.js:40-44: a rush raises the ticket limit to the night's max + 2, and the critic ignores the limit. Up to 9 tickets were seen, but the board draws 6 and shows the rest as "+N". Hidden customers cannot be clicked and leave unseen. Fix: cap the limit at `LAYOUT.ticket.max`, or shrink tickets.
8. MED. stations.js:199-214, state.js:135: W on a simmering pot quietly stops the stirring (no event, toast or sound), and the pot then burns twice as fast. No `info` string anywhere is ever shown (dead text). Fix: make W on a cooking pot a no-op with a toast.
9. LOW. screens.js:348, app.js:177: after King Tide there is no Next button and no campaign-complete message, and Enter does nothing.
10. LOW. input.js:88-91: modifier keys are not filtered. Ctrl+R (reload) is swallowed as the steamer key and Ctrl+S serves. Tab on title, map or results moves focus out of the page.
11. LOW. input.js:68: keys come from `e.key`, so on AZERTY the 1-0 grabs need Shift. Fix: map `e.code` Digit/Numpad.
12. LOW. input.js:29, 35: the locked pot's click area (to y 540) covers the top-left of the Clam Plate's area.
13. LOW. nights.js stars: the scripted chef gets 3 stars on nights 1-2 even at 1.2 s per action (night 1: 547-652 coins against a 520 target). The targets are easy.
