// Artist's probes: per-call draw timings, and full night frames for any night and moment.
import { createNight, stepNight } from '/src/state.js';
import { createAutoChef, chefThink } from '/src/autochef.js';
import * as scene from '/src/render/scene.js';
import * as ui from '/src/render/ui.js';
import { createArmView, drawOctavia, updateArmView } from '/src/render/octopus.js';
import { ambient, createEffects, drawEffects, spawnFromEvents, updateEffects } from '/src/render/effects.js';

function play(nightIndex, seconds, upgrades = { secondPot: true }) {
  const night = createNight({ nightIndex, upgrades, seed: 7 + nightIndex });
  const chef = createAutoChef();
  const view = createArmView();
  const fx = createEffects();
  const frames = Math.round(seconds * 60);
  for (let f = 0; f < frames && !night.over; f++) {
    chefThink(night, chef, 1 / 60);
    stepNight(night, 1 / 60);
    if (f > frames - 120) { ambient(fx, night, 1 / 60, false); spawnFromEvents(fx, night.events, false); updateEffects(fx, 1 / 60); }
    night.events.length = 0;
    updateArmView(view, night, 1 / 60, night.time, false);
  }
  return { night, view, fx };
}

function drawFrame(ctx, { night, view, fx }, calm = false) {
  const t = night.time;
  scene.drawWall(ctx, night, t, calm);
  scene.drawCounter(ctx);
  scene.drawStations(ctx, night, t);
  drawOctavia(ctx, night, view, t);
  scene.drawClamPlate(ctx, night, t);
  scene.drawPass(ctx, night, t);
  scene.drawTrash(ctx);
  scene.drawBins(ctx, t, null);
  scene.drawAtmosphere(ctx, night, t, calm);
  ui.drawOrderBoard(ctx, night, t);
  ui.drawHud(ctx, night, t);
  ui.drawArmSlots(ctx, night, t);
  ui.drawChecklist(ctx, night);
  ui.drawTideGauge(ctx, night, t);
  ui.drawKeyHints(ctx);
  drawEffects(ctx, fx);
}

/** Renders one full frame of a night after `seconds` of scripted play onto a visible canvas. */
export function render(nightIndex, seconds, calm = false) {
  const canvas = document.createElement('canvas');
  canvas.width = 1280;
  canvas.height = 800;
  canvas.style.cssText = 'position:fixed;left:0;top:0';
  document.body.style.margin = '0';
  document.body.appendChild(canvas);
  drawFrame(canvas.getContext('2d'), play(nightIndex, seconds), calm);
  return true;
}

export async function bench(nightIndex = 3) {
  const canvas = document.createElement('canvas');
  canvas.width = 1280;
  canvas.height = 800;
  const ctx = canvas.getContext('2d');
  const { night, view } = play(nightIndex, 40);
  const t = night.time;
  const calls = {
    wall: () => scene.drawWall(ctx, night, t, false),
    counter: () => scene.drawCounter(ctx),
    stations: () => scene.drawStations(ctx, night, t),
    octavia: () => drawOctavia(ctx, night, view, t),
    plate: () => scene.drawClamPlate(ctx, night, t),
    pass: () => scene.drawPass(ctx, night, t),
    bins: () => scene.drawBins(ctx, t, null),
    atmosphere: () => scene.drawAtmosphere(ctx, night, t, false),
    board: () => ui.drawOrderBoard(ctx, night, t),
    hud: () => ui.drawHud(ctx, night, t),
  };
  const out = {};
  for (const fn of Object.values(calls)) fn();
  for (const [k, fn] of Object.entries(calls)) {
    const t0 = performance.now();
    for (let i = 0; i < 30; i++) fn();
    ctx.getImageData(0, 0, 1, 1);
    out[k] = +((performance.now() - t0) / 30).toFixed(2);
  }
  return out;
}
