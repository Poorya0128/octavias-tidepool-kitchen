#!/usr/bin/env node
// QA: what the judge reads. Lists every game source in dossier order (the vendor kit's readGameTree, htmlFacts and
// importOrder) with its bytes, its section bytes in the dossier text and the running total, and marks where the
// text cap cuts and which files the judge never sees. Cross-checked against the kit's own buildDossier text.
//   node /projects/sandbox/tools/qa/dossier-report.mjs [repoRoot] [--cap=163840]
import { readFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const args = process.argv.slice(2);
const repo = resolve(args.find((a) => !a.startsWith('--')) ?? '/projects/sandbox/octavias-tidepool-kitchen');
const CAP = Number((args.find((a) => a.startsWith('--cap=')) ?? '--cap=163840').slice(6));
const kit = await import(pathToFileURL(join(repo, 'vendor/makefun-game.ts')).href);
const gameDir = join(repo, 'game');
const bytesOf = (s) => Buffer.byteLength(s, 'utf8');
const utf8 = new TextDecoder('utf-8');

// The same walk buildDossier does: index.html, the page's import order, then every other source by path.
const tree = kit.readGameTree(gameDir);
const sources = tree.files.filter((f) => f.cls === 'source').map((f) => ({ path: f.path, bytes: new Uint8Array(readFileSync(join(gameDir, f.path))) }));
const facts = kit.htmlFacts(utf8.decode(readFileSync(join(gameDir, 'index.html'))));
const ordered = kit.importOrder(sources, facts).filter((p) => p !== 'index.html');
const reached = new Set(['index.html', ...ordered]);
const rest = sources.map((s) => s.path).filter((p) => !reached.has(p)).sort((a, b) => (a < b ? -1 : a > b ? 1 : 0));
const order = ['index.html', ...ordered, ...rest];
const byPath = new Map(sources.map((s) => [s.path, s]));

/** The section buildDossier writes for a source: heading, fence, text, fence. */
function section(path) {
  const b = byPath.get(path).bytes;
  const t = utf8.decode(b);
  const nl = b.reduce((n, x) => n + (x === 0x0a ? 1 : 0), 0);
  const lines = b.length === 0 ? 0 : b[b.length - 1] === 0x0a ? nl : nl + 1;
  const longest = Math.max(0, ...(t.match(/`+/g) ?? []).map((r) => r.length));
  const fence = '`'.repeat(Math.max(3, longest + 1));
  const lang = /\.(m?js)$/i.test(path) ? 'js' : (/\.([a-z0-9]+)$/i.exec(path)?.[1] ?? 'text').toLowerCase();
  const heading = `### game/${path} (${lines} ${lines === 1 ? 'line' : 'lines'}, ${b.length} bytes)\n\n`;
  const block = lines === 0 ? '' : `${fence}${lang}\n${t}${t.endsWith('\n') ? '' : '\n'}${fence}\n\n`;
  return { path, bytes: b.length, lines, size: bytesOf(heading) + bytesOf(block) };
}
const sections = order.map(section);

// The Game block's size comes from the kit's real text (its header lines are not exported).
let text = null;
try {
  text = JSON.parse(Buffer.from(kit.buildDossier(repo, { text_max_bytes: CAP })).toString('utf8')).text;
} catch (err) {
  console.log(`note: buildDossier refused this repo (${err.message}); header size estimated`);
}
const headEnd = text ? text.indexOf('## Sources\n\n') + '## Sources\n\n'.length : 0;
const headBytes = text ? bytesOf(text.slice(0, headEnd)) : 220;

// Where the cut falls, by buildDossier's rule: a file goes in whole only if the cut line for the rest still fits.
const cutLine = (files, bytes) => `[Cut at ${CAP} bytes: ${files} file${files === 1 ? '' : 's'} and ${bytes} bytes of source left out.]\n`;
let used = headBytes;
let kept = 0;
for (; kept < sections.length; kept++) {
  const restCount = sections.length - kept - 1;
  const restBytes = sections.slice(kept + 1).reduce((n, s) => n + s.bytes, 0);
  if (used + sections[kept].size + (restCount ? bytesOf(cutLine(restCount, restBytes)) : 0) > CAP) break;
  used += sections[kept].size;
}
// The partial file: how many of its lines the judge sees (from the kit's text when available).
const partial = kept < sections.length ? sections[kept] : null;
let partialLines = null;
if (partial && text) {
  const m = /\[(\d+) of this file's (\d+) lines not shown\.\]/.exec(text);
  partialLines = m ? Number(m[2]) - Number(m[1]) : 0;
}

const unseen = new Set(sections.slice(kept + 1).map((s) => s.path));
if (partial && partialLines === 0) unseen.add(partial.path);
// Cross-check with the real text: every file it shows whole or in part.
if (text) {
  const shown = new Set([...text.matchAll(/^### game\/(.+?) \(\d+ lines?, \d+ bytes\)$/gm)].map((m) => m[1]));
  const mine = new Set(sections.filter((s) => !unseen.has(s.path)).map((s) => s.path));
  const same = shown.size === mine.size && [...shown].every((p) => mine.has(p));
  if (!same) console.log(`WARNING: this report disagrees with buildDossier: kit shows ${[...shown].join(', ')}`);
}

console.log(`dossier-report ${repo}  cap ${CAP} B, header ${headBytes} B${text ? `, kit text ${bytesOf(text)} B` : ''}`);
console.log(`${'#'.padStart(2)}  ${'file'.padEnd(28)} ${'bytes'.padStart(6)} ${'section'.padStart(7)} ${'cumul'.padStart(7)}  seen`);
let cumul = headBytes;
sections.forEach((s, i) => {
  cumul += s.size;
  const status = i < kept ? 'whole' : i === kept ? `PARTIAL ${partialLines ?? '?'}/${s.lines} lines` : 'NEVER SEEN';
  const tag = rest.includes(s.path) ? ' (not imported by the page)' : '';
  if (i === kept) console.log(`----  cut at ${CAP} B: ${CAP - used} B of room left for this file  ----`);
  console.log(`${String(i + 1).padStart(2)}  ${s.path.padEnd(28)} ${String(s.bytes).padStart(6)} ${String(s.size).padStart(7)} ${String(cumul).padStart(7)}  ${status}${tag}`);
});
const total = sections.reduce((n, s) => n + s.bytes, 0);
console.log(`source ${sections.length} files ${total} B; whole ${kept}; ${partial ? `cut inside ${partial.path}; the uncut text would be ${cumul} B, ${cumul - CAP} B over the cap` : `no cut, ${CAP - used} B headroom`}`);
if (partial) {
  const whole = sections.slice(kept + 1).reduce((n, s) => n + s.bytes, 0);
  const shownBytes = partialLines ? bytesOf(utf8.decode(byPath.get(partial.path).bytes).split('\n').slice(0, partialLines).join('\n')) + 1 : 0;
  console.log(`judge never sees: ${[...unseen].join(', ') || 'none'} (${whole} B) plus the last ${partial.lines - (partialLines ?? 0)} lines (${partial.bytes - shownBytes} B) of ${partial.path}`);
}
