async (page) => {
  // QA perf probe: frame intervals and canvas calls per frame in a live `?autoplay&speed=1` night (6 s) and in the
  // frozen cover scene (3 s), then the cover scene redrawn 40 times into a separate 1280x800 canvas (JS plus raster,
  // since Chrome flushes the canvas when its command list fills up). Headless Chrome here rasterizes on the CPU, so
  // compare runs with each other rather than with a real GPU. Run with browser_run_code_unsafe, this file as `code`.
  const ROOT = '/projects/sandbox/octavias-tidepool-kitchen';
  const ORIGIN = 'http://game.test';
  const errors = [];
  const browser = page.context().browser();
  const bctx = browser ? await browser.newContext({ viewport: { width: 1280, height: 800 } }) : null;
  const p = bctx ? await bctx.newPage() : await page.context().newPage();
  await p.setViewportSize({ width: 1280, height: 800 });
  p.on('pageerror', (e) => errors.push(String(e)));
  await p.route(`${ORIGIN}/**`, async (route) => {
    let path = route.request().url().slice(ORIGIN.length).split('?')[0].split('#')[0];
    if (path.endsWith('/')) path += 'index.html';
    try { await route.fulfill({ path: `${ROOT}/game${path}`, headers: { 'cache-control': 'no-store' } }); }
    catch (e) { await route.fulfill({ status: 404, body: 'not found' }); }
  });
  await p.addInitScript(() => {
    localStorage.clear();
    const C = { lin: 0, rad: 0, canvas: 0, path2d: 0, drawImage: 0, fill: 0, stroke: 0, arc: 0, fillText: 0, shadow: 0, filter: 0 };
    const P = CanvasRenderingContext2D.prototype;
    const wrap = (name, key, look) => {
      const f = P[name];
      P[name] = function (...a) {
        C[key]++;
        if (look && this.shadowBlur > 0) C.shadow++;
        if (look && this.filter && this.filter !== 'none') C.filter++;
        return f.apply(this, a);
      };
    };
    wrap('createLinearGradient', 'lin'); wrap('createRadialGradient', 'rad'); wrap('arc', 'arc');
    wrap('drawImage', 'drawImage', true); wrap('fill', 'fill', true); wrap('stroke', 'stroke', true); wrap('fillText', 'fillText', true);
    const ce = Document.prototype.createElement;
    Document.prototype.createElement = function (tag, ...r) { if (String(tag).toLowerCase() === 'canvas') C.canvas++; return ce.call(this, tag, ...r); };
    const P2 = window.Path2D;
    window.Path2D = class extends P2 { constructor(...a) { super(...a); C.path2d++; } };
    const frames = [];
    window.__qa = { frames, rec: false };
    const raf = window.requestAnimationFrame.bind(window);
    window.requestAnimationFrame = (cb) => raf((ts) => {
      if (!window.__qa.rec) return cb(ts);
      const before = { ...C };
      const t0 = performance.now();
      cb(ts);
      const dur = performance.now() - t0;
      const d = {};
      for (const k in C) d[k] = C[k] - before[k];
      frames.push({ ts, dur, d });
    });
  });
  const wait = (ms) => p.waitForTimeout(ms);
  const stats = (arr) => {
    const s = [...arr].sort((a, b) => a - b);
    const avg = s.reduce((a, b) => a + b, 0) / (s.length || 1);
    return { avg: +avg.toFixed(1), p95: +(s[Math.floor(s.length * 0.95)] ?? 0).toFixed(1), max: +(s[s.length - 1] ?? 0).toFixed(1) };
  };
  const record = async (ms) => {
    await p.evaluate(() => { window.__qa.frames.length = 0; window.__qa.rec = true; });
    await wait(ms);
    const fr = await p.evaluate(() => { window.__qa.rec = false; return window.__qa.frames.slice(); });
    const iv = fr.slice(1).map((f, i) => f.ts - fr[i].ts);
    const per = {};
    for (const k of Object.keys(fr[0].d)) per[k] = Math.round(fr.reduce((a, f) => a + f.d[k], 0) / fr.length);
    return { fps: +((1000 * (fr.length - 1)) / (fr[fr.length - 1].ts - fr[0].ts)).toFixed(1), intervalMs: stats(iv), over20ms: iv.filter((x) => x > 20).length, of: iv.length, jsMs: stats(fr.map((f) => f.dur)), perFrame: per };
  };
  const ready = () => p.waitForFunction(() => document.body.dataset.ready, null, { timeout: 60000 });
  const out = {};
  await p.goto(`${ORIGIN}/index.html?autoplay&speed=1`);
  await ready();
  await wait(400);
  for (const k of ['Enter', 'Enter', 'Escape']) { await p.keyboard.press(k); await wait(600); }
  await wait(2500);
  out.liveNight = await record(6000);
  await p.goto(`${ORIGIN}/index.html?scene=cover&seed=7`);
  await ready();
  await wait(800);
  out.coverScene = await record(3000);
  out.coverRedraw = await p.evaluate(async (origin) => {
    const [appM, shots, campaign, audio] = await Promise.all(['app', 'shots', 'campaign', 'audio'].map((f) => import(`${origin}/src/${f}.js`)));
    const app = appM.createApp({ campaign: campaign.loadCampaign(), audio: audio.createAudio() });
    shots.applyScene(app, 'cover', 7);
    const cv = document.createElement('canvas');
    cv.width = 1280;
    cv.height = 800;
    const ctx = cv.getContext('2d');
    for (let i = 0; i < 5; i++) appM.drawApp(ctx, app);
    const s = performance.now();
    for (let i = 0; i < 40; i++) appM.drawApp(ctx, app);
    ctx.getImageData(0, 0, 1, 1);
    return { avgMsPerRedraw: +((performance.now() - s) / 40).toFixed(1) };
  }, ORIGIN).catch((e) => ({ error: String(e) }));
  await p.close();
  if (bctx) await bctx.close();
  return JSON.stringify({ errors, ...out });
}
