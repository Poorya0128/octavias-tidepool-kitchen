// Times each night-screen draw call over 30 frames on a 1280x800 canvas (artist's perf probe).
import { createNight, stepNight } from '/src/state.js';
import { createAutoChef, chefThink } from '/src/autochef.js';
import * as scene from '/src/render/scene.js';
import * as ui from '/src/render/ui.js';
import { createArmView, drawOctavia, updateArmView } from '/src/render/octopus.js';

export async function bench(nightIndex = 3) {
  const canvas = document.createElement('canvas');
  canvas.width = 1280;
  canvas.height = 800;
  document.body.appendChild(canvas);
  const ctx = canvas.getContext('2d');
  const night = createNight({ nightIndex, upgrades: { secondPot: true }, seed: 7 });
  const chef = createAutoChef();
  const view = createArmView();
  for (let f = 0; f < 60 * 40; f++) { chefThink(night, chef, 1 / 60); stepNight(night, 1 / 60); night.events.length = 0; updateArmView(view, night, 1 / 60, night.time, false); }
  const t = night.time;
  const calls = {
    wall: () => scene.drawWall(ctx, night, t, false),
    counter: () => scene.drawCounter(ctx),
    stations: () => scene.drawStations(ctx, night, t),
    octavia: () => drawOctavia(ctx, night, view, t),
    plate: () => scene.drawClamPlate(ctx, night, t),
    pass: () => scene.drawPass(ctx, night, t),
    bins: () => scene.drawBins(ctx, t, null),
    atmosphere: () => scene.drawAtmosphere(ctx, night, t, false),
    board: () => ui.drawOrderBoard(ctx, night, t),
    hud: () => ui.drawHud(ctx, night, t),
  };
  const out = {};
  for (const [k, fn] of Object.entries(calls)) { fn(); }
  for (const [k, fn] of Object.entries(calls)) {
    const t0 = performance.now();
    for (let i = 0; i < 30; i++) fn();
    ctx.getImageData(0, 0, 1, 1);
    out[k] = +((performance.now() - t0) / 30).toFixed(2);
  }
  return out;
}
