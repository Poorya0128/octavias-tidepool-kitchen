async (page) => {
  // QA browser check: plays the real flow with keyboard and mouse, then lets the scripted chef finish a night.
  // Run with browser_run_code_unsafe { filename: '/projects/sandbox/tools/qa/browser-check.js' }.
  // Switch repos by editing ROOT. Screenshots go to OUT as bc-*.jpg. Returns JSON {errors, offsite, steps, reachedResults}.
  const ROOT = '/projects/sandbox/octavias-tidepool-kitchen';
  const OUT = '/projects/sandbox/tools/qa';
  const ORIGIN = 'http://game.test';
  const steps = [];
  const errors = [];
  const offsite = [];

  // Our own context when possible (fresh localStorage, so the first-night help card shows); else our own page.
  const browser = page.context().browser();
  const ctx = browser ? await browser.newContext({ viewport: { width: 1280, height: 800 } }) : null;
  const p = ctx ? await ctx.newPage() : await page.context().newPage();
  await p.setViewportSize({ width: 1280, height: 800 });
  p.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  p.on('pageerror', (e) => errors.push(String(e)));
  p.on('request', (r) => { if (!r.url().startsWith(`${ORIGIN}/`)) offsite.push(r.url()); });
  await p.route(`${ORIGIN}/**`, async (route) => {
    let path = route.request().url().slice(ORIGIN.length).split('?')[0].split('#')[0];
    if (path.endsWith('/')) path += 'index.html';
    try { await route.fulfill({ path: `${ROOT}/game${path}`, headers: { 'cache-control': 'no-store' } }); }
    catch (e) { await route.fulfill({ status: 404, body: 'not found' }); }
  });
  // Observe the canvas text each frame (fillText), so steps can check what the player would read.
  await p.addInitScript(() => {
    const seen = new Map();
    let frame = 0;
    const fill = CanvasRenderingContext2D.prototype.fillText;
    CanvasRenderingContext2D.prototype.fillText = function (t, x, y, ...rest) {
      seen.set(String(t), { frame, x, y });
      return fill.call(this, t, x, y, ...rest);
    };
    const raf = window.requestAnimationFrame.bind(window);
    window.requestAnimationFrame = (cb) => raf((ts) => { frame++; cb(ts); });
    window.__qaFrame = () => frame;
    // Texts drawn since a frame number (default: the last frame drawn).
    window.__qaTexts = (since) => [...seen].filter(([, v]) => v.frame >= (since ?? frame - 1)).map(([t, v]) => ({ t, x: Math.round(v.x), y: Math.round(v.y) }));
    // Every WebAudio note start, to catch bursts of notes scheduled in the past.
    window.__qaStarts = [];
    const start = AudioScheduledSourceNode.prototype.start;
    AudioScheduledSourceNode.prototype.start = function (when = 0, ...rest) {
      window.__qaStarts.push({ at: performance.now(), late: when > 0 && when < this.context.currentTime - 0.05 });
      return start.call(this, when, ...rest);
    };
    if (!sessionStorage.getItem('qa-cleared')) { localStorage.clear(); sessionStorage.setItem('qa-cleared', '1'); }
  });

  const wait = (ms) => p.waitForTimeout(ms);
  const screen = () => p.evaluate(() => document.body.dataset.screen ?? null);
  const texts = (since) => p.evaluate((s) => window.__qaTexts(s), since ?? null).catch(() => []);
  const frameNow = () => p.evaluate(() => window.__qaFrame());
  const has = async (re, since) => (await texts(since)).some((x) => re.test(x.t));
  let shotN = 0;
  const shot = async (name) => {
    const file = `${OUT}/bc-${String(++shotN).padStart(2, '0')}-${name}.jpg`;
    await p.screenshot({ path: file, type: 'jpeg', quality: 80 });
    return file.slice(OUT.length + 1);
  };
  const step = async (name, fn) => {
    const before = errors.length;
    try {
      const note = await fn();
      steps.push({ name, ok: errors.length === before && note?.ok !== false, screen: await screen(), ...(note ?? {}), ...(errors.length > before ? { newErrors: errors.slice(before) } : {}) });
    } catch (e) {
      steps.push({ name, ok: false, screen: await screen().catch(() => null), error: String(e).split('\n')[0] });
    }
  };
  const press = async (key, gap = 120) => { await p.keyboard.press(key); await wait(gap); };
  /** Canvas logical point to page point (the canvas is scaled to fit the window). */
  const toPage = async (x, y) => {
    const r = await p.evaluate(() => { const b = document.getElementById('game').getBoundingClientRect(); return { l: b.left, t: b.top, w: b.width, h: b.height }; });
    return { x: r.l + (x * r.w) / 1280, y: r.t + (y * r.h) / 800 };
  };
  const click = async (x, y) => { const q = await toPage(x, y); await p.mouse.click(q.x, q.y); await wait(150); };
  const coins = async () => {
    const t = (await texts()).filter((x) => /^\d+$/.test(x.t) && x.x > 1100 && x.y > 60 && x.y < 110);
    return t.length ? Number(t[0].t) : null;
  };

  await step('load title', async () => {
    await p.goto(`${ORIGIN}/index.html`);
    await p.waitForFunction(() => document.body.dataset.ready, null, { timeout: 60000 });
    await wait(600);
    return { ok: (await screen()) === 'title', shot: await shot('title') };
  });
  // Game data straight from the build under test, so the plan follows its recipes, keys and layout.
  const data = await p.evaluate(async (origin) => {
    const [{ RECIPES }, { INGREDIENTS }, { LAYOUT }] = await Promise.all(['data/recipes.js', 'data/ingredients.js', 'config.js'].map((f) => import(`${origin}/src/${f}`)));
    return { recipes: RECIPES.map((r) => ({ id: r.id, name: r.name, parts: r.parts })), keys: Object.fromEntries(INGREDIENTS.map((i) => [i.id, i.key])), ings: INGREDIENTS.map((i) => i.id), LAYOUT };
  }, ORIGIN);
  const L = data.LAYOUT;
  const binCenter = (i) => ({ x: L.bins.x + i * (L.bins.w + L.bins.gap) + L.bins.w / 2, y: L.bins.y + L.bins.h / 2 });
  const stationCenter = (id) => ({ x: L.stations[id].x + L.stations[id].w / 2, y: L.stations[id].y + L.stations[id].h / 2 });

  await step('Enter: title -> map', async () => { await press('Enter', 500); return { ok: (await screen()) === 'map', shot: await shot('map') }; });
  await step('Enter: map -> night 1 (help card)', async () => {
    await press('Enter', 700);
    const help = await has(/HOW TO|How to/i);
    return { ok: (await screen()) === 'night', help, shot: await shot('night-help') };
  });
  await step('close help card', async () => {
    if (await has(/HOW TO RUN|press H or click to close/i)) await press('Escape', 400);
    const still = await has(/press H or click to close/i, await frameNow());
    await wait(1600); // first ticket arrives at 1.5 s
    return { ok: !still, shot: await shot('kitchen') };
  });

  // The instructed opening: 6 then R (rice into the steamer), 1 then Q (kelp onto the board).
  let target = null;
  await step('6 R, 1 Q: rice to steamer, kelp to board', async () => {
    const tickets = (await texts()).filter((x) => data.recipes.some((r) => r.name === x.t) && x.y > 60 && x.y < 160).sort((a, b) => a.x - b.x);
    target = data.recipes.find((r) => r.name === tickets[0]?.t) ?? null;
    await press('6'); await press('r'); await press('1'); await press('q', 600);
    return { ticket: target?.name ?? 'none seen', shot: await shot('placed') };
  });

  // Finish the first (selected) ticket's dish with the keys, timed on the real cooking clocks.
  await step('cook, plate (Space x2) and serve (S) the first ticket', async () => {
    if (!target) return { ok: false, note: 'no ticket on the board' };
    const coinsBefore = await coins();
    const PREP_KEY = { chop: 'q', steam: 'r', sear: 'e', simmer: 'w' };
    const plan = [];
    const opening = target.parts.some(([i, pr]) => i === 'rice' && pr === 'steam') && target.parts.some(([i, pr]) => i === 'kelp' && pr === 'chop');
    let chopAt = opening ? 0 : 2.4; // the board is busy with the opening kelp for about 2 s
    for (const [ing, prep] of target.parts) {
      const k = data.keys[ing];
      if (prep === 'raw') { plan.push([0.3, k]); continue; }
      if (opening && ((ing === 'rice' && prep === 'steam') || (ing === 'kelp' && prep === 'chop'))) {
        if (prep === 'steam') plan.push([6.2, 'r']);
        continue;
      }
      const t0 = prep === 'chop' ? chopAt : 0.4;
      plan.push([t0, k], [t0 + 0.15, PREP_KEY[prep]]);
      if (prep === 'chop') chopAt += 2.6;
      if (prep === 'sear') plan.push([t0 + 3.4, 'e'], [t0 + 6.0, 'e']);
      if (prep === 'steam') plan.push([t0 + 6.6, 'r']);
      if (prep === 'simmer') plan.push([t0 + 6.0, 'w']);
    }
    const end = Math.max(...plan.map((e) => e[0])) + 0.8;
    plan.push([end, ' '], [end + 0.6, ' '], [end + 1.4, 's']);
    plan.sort((a, b) => a[0] - b[0]);
    const t0 = Date.now();
    for (const [at, key] of plan) {
      const delay = at * 1000 - (Date.now() - t0);
      if (delay > 0) await wait(delay);
      await p.keyboard.press(key === ' ' ? 'Space' : key);
    }
    await wait(500);
    const shotFile = await shot('served');
    await wait(400);
    const coinsAfter = await coins();
    const popup = await has(/^\+\d+/, (await frameNow()) - 90);
    return { ok: coinsAfter !== null && coinsBefore !== null && coinsAfter > coinsBefore, plan: plan.map(([a, k]) => `${a.toFixed(1)}:${k === ' ' ? 'Space' : k}`).join(' '), coinsBefore, coinsAfter, popup, shot: shotFile };
  });

  await step('Backspace bins a leftover, Tab cycles tickets', async () => { await press('Backspace'); await press('Tab', 300); return { shot: await shot('tab') }; });
  await step('P pauses, P resumes', async () => {
    await press('p', 400);
    const paused = await has(/^PAUSED$/);
    const file = await shot('pause');
    await press('p', 400);
    const resumed = !(await has(/^PAUSED$/, await frameNow()));
    return { ok: paused && resumed, paused, resumed, shot: file };
  });
  await step('audio: after a 3 s pause the music does not burst', async () => {
    await press('p', 3000);
    const t = await p.evaluate(() => performance.now());
    await press('p', 600);
    const r = await p.evaluate((t0) => {
      const s = window.__qaStarts.filter((x) => x.at >= t0 && x.at < t0 + 300);
      return { notes: s.length, late: s.filter((x) => x.late).length };
    }, t);
    return { ok: r.notes <= 8, notesIn300ms: r.notes, scheduledInPast: r.late };
  });
  await step('H opens help, Escape closes it', async () => {
    await press('h', 400);
    const open = await has(/press H or click to close/i);
    const file = await shot('help');
    await press('Escape', 400);
    const closed = !(await has(/press H or click to close/i, await frameNow()));
    return { ok: open && closed && (await screen()) === 'night', open, closed, shot: file };
  });
  await step('M twice (mute, unmute)', async () => { await press('m', 200); await press('m', 200); return { ok: (await screen()) === 'night' }; });

  await step('mouse: click a bin, then a station', async () => {
    const bin = binCenter(data.ings.indexOf('kelp'));
    await click(bin.x, bin.y);
    const board = stationCenter('board');
    await click(board.x, board.y);
    await wait(300);
    return { bin, board, shot: await shot('mouse-click') };
  });
  await step('mouse: drag milk from its bin onto the pot', async () => {
    const bin = binCenter(data.ings.indexOf('milk'));
    const pot = stationCenter('pot0');
    const a = await toPage(bin.x, bin.y);
    const b = await toPage(pot.x, pot.y);
    await p.mouse.move(a.x, a.y);
    await p.mouse.down();
    await p.mouse.move((a.x + b.x) / 2, (a.y + b.y) / 2, { steps: 4 });
    await p.mouse.move(b.x, b.y, { steps: 4 });
    await p.mouse.up();
    await wait(500);
    return { shot: await shot('mouse-drag') };
  });

  // The scripted chef plays a whole night at 20x; the page must reach the results screen on its own.
  let reachedResults = false;
  await step('autoplay night 1 at speed 20 to results', async () => {
    await p.goto(`${ORIGIN}/index.html?autoplay&speed=20`);
    await p.waitForFunction(() => document.body.dataset.ready, null, { timeout: 60000 });
    await wait(400);
    await press('Enter', 500);
    await press('Enter', 700);
    if (await has(/press H or click to close/i)) await press('Escape', 300);
    const started = Date.now();
    await p.waitForFunction(() => document.body.dataset.screen === 'results', null, { timeout: 90000 });
    reachedResults = true;
    const seconds = Math.round((Date.now() - started) / 100) / 10;
    // A steamer key (R) still pressed as the night ends must not skip the results screen.
    await p.keyboard.press('r');
    await wait(150);
    const afterR = await screen();
    if (afterR !== 'results') await p.waitForFunction(() => document.body.dataset.screen === 'results', null, { timeout: 90000 });
    await wait(1500);
    const summary = (await texts()).map((x) => x.t).filter((t) => /coins$|COMPLETE/.test(t));
    return { ok: afterR === 'results', seconds, screenAfterLateR: afterR, summary, shot: await shot('results') };
  });
  await step('M on results (help card says M mutes)', async () => {
    if (!reachedResults) return { ok: false, note: 'results not reached' };
    await press('m', 500);
    const now = await screen();
    return { ok: true, screenAfterM: now, shot: await shot('after-m-on-results') };
  });

  await p.close();
  if (ctx) await ctx.close();
  return JSON.stringify({ root: ROOT, errors, offsite, steps, reachedResults }, null, 1);
}
