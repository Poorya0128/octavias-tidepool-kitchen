// Screenshot frame search for Octavia's Tidepool Kitchen (Node 22, imports the game modules).
// Replays each service scene exactly like game/src/shots.js (same campaign path through
// playCampaign, same BUYS, the scene's seed from shots.json), scores every frame of the night
// for every chef style of a grid, and prints the best frames. --write stores the winner of each
// searched scene in the PLAYS table of shots.js.
//   node find-frames.mjs [--scene cover|moon|critic] [--seed n | --seeds a-b] [--coarse]
//                        [--part k/n] [--chef '{"cadence":0.5,...}'] [--write]
// --part k/n searches every n-th chef style (to split a search over processes); --chef replays
// a single style, which is the quick way to --write a winner found earlier. --check replays the
// frames stored in shots.js and says whether each still meets its musts (run it after any logic
// change: a different step anywhere moves every later frame). A full search of one scene takes
// about 3 minutes; run the scenes (or --part 0/2 and 1/2) as parallel processes.

import { readFileSync, writeFileSync } from 'node:fs';

const REPO = '/projects/sandbox/octavias-tidepool-kitchen';
const SRC = `${REPO}/game/src/`;
const { LAYOUT, STEP } = await import(SRC + 'config.js');
const { createNight, stepNight } = await import(SRC + 'state.js');
const { createAutoChef, chefThink, playCampaign } = await import(SRC + 'autochef.js');
const { missingParts, ticketForPlate } = await import(SRC + 'orders.js');
const { streakMultiplier } = await import(SRC + 'scoring.js');

const args = process.argv.slice(2);
const flag = (name) => { const i = args.indexOf(name); return i >= 0 ? args[i + 1] : null; };
const WRITE = args.includes('--write');

const SHOTS = SRC + 'shots.js';
const shotsText = readFileSync(SHOTS, 'utf8');
/** Evaluates one `const NAME = {...};` literal of shots.js. */
function literal(name) {
  const m = shotsText.match(new RegExp(`const ${name} = (\\{[\\s\\S]*?\\});\\n`));
  if (!m) throw new Error(`shots.js has no const ${name}`);
  return Function(`return (${m[1]});`)();
}
const BUYS = literal('BUYS');
const PLAYS = literal('PLAYS');
const SHOT_SEEDS = Object.fromEntries(JSON.parse(readFileSync(`${REPO}/shots.json`, 'utf8'))
  .map((s) => [s.query.match(/scene=(\w+)/)?.[1], Number(s.query.match(/seed=(\d+)/)?.[1] ?? 7)]));

/** Scene-specific musts (on top of the shared ones) and bonuses. */
const WANTS = {
  cover: {
    must: (s, front) => s.rush.active && ['shelby', 'puffy'].includes(front.customerId),
    bonus: () => 0,
  },
  moon: {
    must: (s, front) => front.customerId === 'twins',
    bonus: (s) => (s.tickets.filter((t) => t.customerId === 'twins').length >= 2 ? 1 : 0),
  },
  critic: {
    must: (s) => s.tickets.slice(0, LAYOUT.ticket.max).some((t) => t.critic)
      && (s.plate.recipeId === 'platter' || s.pass.some((p) => p.recipeId === 'platter')),
    bonus: (s) => (s.plate.recipeId === 'platter' ? 3 : 0),
  },
};

/** Whether some ticket still needs this dish once the plates waiting at the window are handed out. */
function stillWanted(s, recipeId) {
  const asked = s.tickets.filter((t) => t.recipeId === recipeId).length;
  return asked > s.pass.filter((p) => p.recipeId === recipeId).length;
}

/** The chef styles searched: cadence x serveAfter x focus x takeWithin (null keeps "take at once"). */
function chefStyles(coarse) {
  const cadences = [];
  for (let c = 0.3; c <= 0.9001; c += coarse ? 0.05 : 0.02) cadences.push(Math.round(c * 100) / 100);
  const out = [];
  for (const cadence of cadences) for (const serveAfter of [0, 2, 4, 6, 8, 10, 12, 14, 16]) for (const focus of [2, 3, 4, 5]) {
    for (const takeWithin of [null, 2, 1.6, 1.1, 0.7]) {
      out.push(takeWithin === null ? { cadence, serveAfter, focus } : { cadence, serveAfter, focus, takeWithin });
    }
  }
  return out;
}

/** Station items over every unlocked station. */
function stationItems(s) {
  return Object.values(s.stations).filter((st) => !st.locked).flatMap((st) => st.slots).filter(Boolean);
}

/** null when a frame misses a must; otherwise its score (higher looks busier and clearer). */
function scoreFrame(s, want) {
  const left = s.cfg.duration - s.time;
  if (left < 35 || left > 145 || s.ink.active || s.ink.meter < 0.3 || s.ink.meter > 0.95) return null;
  if (s.tickets.length < 5 || !s.pass.length) return null;
  const front = ticketForPlate(s, s.pass[0]);
  if (!front) return null;
  const plate = s.plate;
  if (!plate.recipeId || plate.parts.length < 2 || !missingParts(plate.recipeId, plate.parts).length) return null;
  if (!stillWanted(s, plate.recipeId)) return null;
  const items = stationItems(s);
  const live = items.filter((i) => i.phase !== 'burnt');
  const perfect = live.filter((i) => i.phase === 'perfect').length;
  if (live.length < 3 || perfect < 1) return null;
  if (!want.must(s, front)) return null;
  const talking = s.speech.some((sp) => sp.ticketId === front.id && s.time - sp.at < 4);
  const recentServe = s.time - (s.moments.serve ?? -99) < 1.2;
  const sourToasts = s.toasts.filter((t) => !/Shelby|Twin|bonus/i.test(t.text)).length;
  const strays = s.pass.filter((p) => !ticketForPlate(s, p)).length;
  const holding = s.arms.filter((a) => a.state === 'hold').length;
  const busyKinds = new Set(live.map((i) => i.prep)).size;
  return 2 * perfect + live.length + busyKinds - 4 * (items.length - live.length) + Math.min(s.tickets.length, 6)
    + plate.parts.length + s.pass.length - 3 * strays + 0.5 * Math.min(holding, 4) + 2 * s.ink.meter
    + (talking ? 3 : 0) + (recentServe ? 1.5 : 0) + (streakMultiplier(s.streak) > 1 ? 1 : 0)
    - 1.5 * sourToasts + want.bonus(s);
}

/** A short description of the frozen frame, for the report. */
function describe(s) {
  const left = s.cfg.duration - s.time;
  const clock = `${Math.floor(left / 60)}:${String(Math.floor(left % 60)).padStart(2, '0')}`;
  const front = ticketForPlate(s, s.pass[0]);
  const items = stationItems(s).map((i) => `${i.ing}:${i.phase}`).join(' ');
  const talk = s.speech.filter((sp) => sp.ticketId === front.id && s.time - sp.at < 4).map((sp) => `"${sp.text}"`).join(', ');
  return `clock ${clock} left, ${s.tickets.length} tickets [${s.tickets.map((t) => `${t.customerId}:${t.recipeId}`).join(' ')}]\n`
    + `    plate ${s.plate.recipeId} ${s.plate.parts.length} parts, window [${s.pass.map((p) => p.recipeId).join(' ')}] front for ${front.customerId}\n`
    + `    stations ${items}; ink ${s.ink.meter.toFixed(2)} (${s.ink.uses} bursts), streak ${s.streak} x${streakMultiplier(s.streak)}, rush ${s.rush.active}`
    + `, toasts [${s.toasts.map((t) => t.text).join(' | ')}], front diner says: ${talk || 'nothing'}`;
}

/** Best frame of one night for one chef style: { frames, score, text } or null. */
function searchNight(nightIndex, upgrades, seed, chefOpts, want) {
  const s = createNight({ nightIndex, upgrades, seed });
  const chef = createAutoChef(chefOpts);
  let best = null;
  for (let f = 1; !s.over && s.time < s.cfg.duration - 34; f++) {
    chefThink(s, chef, STEP);
    stepNight(s, STEP);
    s.events.length = 0;
    const score = scoreFrame(s, want);
    if (score !== null && (!best || score > best.score)) best = { frames: f, score, text: describe(s) };
  }
  return best;
}

/** The seeds to try for a scene: --seed n, --seeds a-b, else the scene's shots.json seed (or 7). */
function seedsFor(name) {
  const range = flag('--seeds');
  if (range) {
    const [a, b] = range.split('-').map(Number);
    return Array.from({ length: b - a + 1 }, (_, i) => a + i);
  }
  return [Number(flag('--seed') ?? SHOT_SEEDS[name] ?? 7)];
}

if (args.includes('--check')) {
  for (const [name, play] of Object.entries(PLAYS)) {
    const seed = seedsFor(name)[0];
    const { upgrades } = playCampaign(play.night, seed, BUYS);
    const s = createNight({ nightIndex: play.night, upgrades, seed });
    const chef = createAutoChef(play.chef);
    for (let f = 0; f < play.frames && !s.over; f++) {
      chefThink(s, chef, STEP);
      stepNight(s, STEP);
      s.events.length = 0;
    }
    const score = scoreFrame(s, WANTS[name]);
    console.log(`${name} (seed ${seed}) frame ${play.frames}: ${score === null ? 'FAILS a must, search again' : `ok, score ${score.toFixed(1)}\n    ${describe(s)}`}`);
  }
  process.exit(0);
}

const only = flag('--scene');
const [part, parts] = (flag('--part') ?? '0/1').split('/').map(Number);
const styles = flag('--chef') ? [JSON.parse(flag('--chef'))] : chefStyles(args.includes('--coarse')).filter((_, i) => i % parts === part);
const winners = {};
for (const [name, play] of Object.entries(PLAYS)) {
  if (only && name !== only) continue;
  for (const seed of seedsFor(name)) {
    const { upgrades } = playCampaign(play.night, seed, BUYS);
    const found = [];
    for (const chef of styles) {
      const best = searchNight(play.night, upgrades, seed, chef, WANTS[name]);
      if (best) found.push({ ...best, chef, seed });
    }
    found.sort((a, b) => b.score - a.score);
    console.log(`${name} (night ${play.night}, seed ${seed}, upgrades ${Object.keys(upgrades).join(',')}): ${found.length}/${styles.length} chef styles have a valid frame`);
    for (const r of found.slice(0, 3)) console.log(`  frames ${r.frames} chef ${JSON.stringify(r.chef)} score ${r.score.toFixed(1)}\n    ${r.text}`);
    if (found[0] && (!winners[name] || found[0].score > winners[name].score)) winners[name] = found[0];
  }
}

if (WRITE && Object.keys(winners).length) {
  const lines = Object.entries(PLAYS).map(([name, play]) => {
    const r = winners[name];
    const chef = r ? r.chef : play.chef;
    const chefText = Object.entries(chef).map(([k, v]) => `${k}: ${v}`).join(', ');
    return `  ${name}: { night: ${play.night}, frames: ${r ? r.frames : play.frames}, chef: { ${chefText} } },`;
  });
  writeFileSync(SHOTS, shotsText.replace(/const PLAYS = \{[\s\S]*?\};\n/, `const PLAYS = {\n${lines.join('\n')}\n};\n`));
  for (const [name, r] of Object.entries(winners)) console.log(`shots.js: ${name} -> frames ${r.frames}, chef ${JSON.stringify(r.chef)} (seed ${r.seed})`);
}
