#!/bin/bash
# Starts the static game server detached on 8765 and checks it answers.
cd /projects/sandbox/octavias-tidepool-kitchen || exit 1
if ! curl -s -o /dev/null http://127.0.0.1:8765/index.html; then
  setsid nohup node serve.ts --port 8765 > /tmp/serve.log 2>&1 < /dev/null &
  sleep 1.5
fi
curl -s -o /dev/null -w "status %{http_code}\n" http://127.0.0.1:8765/index.html
cat /tmp/serve.log
