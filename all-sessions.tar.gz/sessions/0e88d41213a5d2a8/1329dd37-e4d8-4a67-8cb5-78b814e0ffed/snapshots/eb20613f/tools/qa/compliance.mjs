#!/usr/bin/env node
// QA: checks an entry against the make.fun cooking bounty rules.
//   node /projects/sandbox/tools/qa/compliance.mjs [repoRoot] [--keep]
// repoRoot defaults to the live repo; --keep leaves the main.ts output dir in place. Exit code 1 on any FAIL.
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { existsSync, mkdtempSync, readdirSync, readFileSync, rmSync, statSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, relative, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const args = process.argv.slice(2);
const repo = resolve(args.find((a) => !a.startsWith('--')) ?? '/projects/sandbox/octavias-tidepool-kitchen');
const KIT_COMMIT = '27d043c';
const CAPS = { text_max_bytes: 163840, screenshots: { max: 4, max_bytes: 262144 }, game_max_files: 993, game_max_bytes: 50331648, game_path_max_bytes: 1000 };
const IMAGE_NAME = /^[A-Za-z0-9_][A-Za-z0-9._-]{0,127}$/;
const gameDir = join(repo, 'game');
const results = [];
const check = (level, name, detail = '') => results.push({ level, name, detail });
const pass = (name, detail) => check('PASS', name, detail);
const fail = (name, detail) => check('FAIL', name, detail);
const warn = (name, detail) => check('WARN', name, detail);
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const posix = (p) => p.split('\\').join('/');

/** Every file under a directory, as POSIX paths relative to it. */
function walk(dir, base = dir, out = []) {
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    const p = join(dir, e.name);
    if (e.isDirectory()) walk(p, base, out);
    else out.push(posix(relative(base, p)));
  }
  return out;
}
const countEntries = (dir) => readdirSync(dir, { withFileTypes: true }).reduce((n, e) => n + 1 + (e.isDirectory() ? countEntries(join(dir, e.name)) : 0), 0);

/** Width and height of a PNG or JPEG, or null. */
function imageSize(b) {
  if (b[0] === 0x89 && b[1] === 0x50) return { type: 'png', w: b.readUInt32BE(16), h: b.readUInt32BE(20) };
  if (b[0] !== 0xff || b[1] !== 0xd8) return null;
  for (let i = 2; i + 9 < b.length;) {
    if (b[i] !== 0xff) { i++; continue; }
    const marker = b[i + 1];
    if (marker >= 0xc0 && marker <= 0xcf && ![0xc4, 0xc8, 0xcc].includes(marker)) return { type: 'jpeg', w: b.readUInt16BE(i + 7), h: b.readUInt16BE(i + 5) };
    i += 2 + b.readUInt16BE(i + 2);
  }
  return { type: 'jpeg', w: 0, h: 0 };
}

/** JS text with comments blanked (strings, templates and regex literals kept), newlines preserved. */
function stripComments(src) {
  let out = '';
  let prev = '';
  for (let i = 0; i < src.length;) {
    const c = src[i];
    const d = src[i + 1];
    if (c === '/' && d === '/') {
      const j = src.indexOf('\n', i);
      i = j < 0 ? src.length : j;
    } else if (c === '/' && d === '*') {
      const j = src.indexOf('*/', i + 2);
      const end = j < 0 ? src.length : j + 2;
      out += src.slice(i, end).replace(/[^\n]/g, ' ');
      i = end;
    } else if (c === '"' || c === "'" || c === '`') {
      let j = i + 1;
      while (j < src.length && src[j] !== c && !(c !== '`' && src[j] === '\n')) j += src[j] === '\\' ? 2 : 1;
      out += src.slice(i, j + 1);
      i = j + 1;
      prev = c;
    } else if (c === '/' && (prev === '' || '(,=:[!&|?{};+-*%<>~^'.includes(prev))) {
      let j = i + 1;
      let inClass = false;
      while (j < src.length && src[j] !== '\n' && (src[j] !== '/' || inClass)) {
        if (src[j] === '\\') j++;
        else if (src[j] === '[') inClass = true;
        else if (src[j] === ']') inClass = false;
        j++;
      }
      j++;
      while (j < src.length && /[a-z]/i.test(src[j])) j++;
      out += src.slice(i, j);
      i = j;
      prev = '/';
    } else {
      out += c;
      if (!/\s/.test(c)) prev = c;
      i++;
    }
  }
  return out;
}

const NETWORK_JS = [
  [/\bfetch\s*\(/g, 'fetch('], [/\bXMLHttpRequest\b/g, 'XMLHttpRequest'], [/\bWebSocket\b/g, 'WebSocket'],
  [/\bEventSource\b/g, 'EventSource'], [/\bsendBeacon\b/g, 'sendBeacon'], [/(?:^|[^.\w$])import\s*\(/g, 'dynamic import()'],
  [/\bimportScripts\s*\(/g, 'importScripts'], [/\bserviceWorker\b/g, 'serviceWorker'], [/\bRTCPeerConnection\b/g, 'RTCPeerConnection'],
  [/\bWebTransport\b/g, 'WebTransport'], [/\bwindow\.open\s*\(/g, 'window.open'], [/\bnew\s+(?:Shared)?Worker\s*\(/g, 'Worker'],
  [/\bnew\s+(?:Image|Audio)\s*\(/g, 'Image/Audio element (loads a URL)'], [/\.(?:src|href)\s*=/g, '.src/.href assignment'],
];
const ABSOLUTE_URL = /(['"`])\s*((?:https?:|wss?:|ftp:)?\/\/[^'"`\s]*)/g;
const URL_ALLOW = /^https?:\/\/www\.w3\.org\//;
const lineOf = (s, index) => s.slice(0, index).split('\n').length;

/** Network calls and absolute URLs in one JS text; `at` names the file for messages. */
function scanJs(code, at, problems) {
  const s = stripComments(code);
  for (const [re, what] of NETWORK_JS) for (const m of s.matchAll(re)) problems.push(`${at}:${lineOf(s, m.index)} ${what}`);
  for (const m of s.matchAll(ABSOLUTE_URL)) if (!URL_ALLOW.test(m[2])) problems.push(`${at}:${lineOf(s, m.index)} absolute URL ${m[2].slice(0, 60)}`);
}

/** url(...) and @import in CSS text. */
function scanCss(css, at, problems, fromPath, exists, kit) {
  for (const m of css.matchAll(/@import\b/g)) problems.push(`${at}:${lineOf(css, m.index)} CSS @import`);
  for (const m of css.matchAll(/url\(\s*['"]?([^'")\s]*)/g)) {
    const ref = m[1];
    if (ref.startsWith('data:') || ref.startsWith('#') || ref === '') continue;
    const target = kit.resolveGamePath(ref, fromPath);
    if (target === null || !exists(target)) problems.push(`${at}:${lineOf(css, m.index)} url(${ref.slice(0, 60)}) is not a file of game/`);
  }
}

// ------------------------------------------------------------ run
const major = process.versions.node.split('.').map(Number);
if (major[0] > 22 || (major[0] === 22 && major[1] >= 18)) pass('node version', process.versions.node);
else warn('node version', `${process.versions.node}: the bounty runs Node 22.18+`);

for (const f of ['main.ts', 'vendor/makefun-game.ts', 'LICENSE', 'game/index.html', 'screenshots']) {
  if (!existsSync(join(repo, f))) fail('required file', `${f} is missing`);
}
const kitPath = join(repo, 'vendor/makefun-game.ts');
if (!existsSync(kitPath)) {
  report();
}
const kit = await import(pathToFileURL(kitPath).href);

// vendor file byte-identical to the kit
const kitGit = spawnSync('git', ['-C', repo, 'show', `${KIT_COMMIT}:vendor/makefun-game.ts`], { encoding: 'buffer', maxBuffer: 1 << 24 });
if (kitGit.status !== 0) fail('vendor identical to kit', `git show ${KIT_COMMIT} failed: ${kitGit.stderr.toString().trim()}`);
else if (sha(kitGit.stdout) === sha(readFileSync(kitPath))) pass('vendor identical to kit', `sha256 ${sha(kitGit.stdout).slice(0, 16)}`);
else fail('vendor identical to kit', `vendor/makefun-game.ts differs from ${KIT_COMMIT}`);
const vendorExtra = readdirSync(join(repo, 'vendor')).filter((f) => f !== 'makefun-game.ts');
if (vendorExtra.length) warn('vendor dir', `extra files: ${vendorExtra.join(', ')}`);

// MIT license
if (existsSync(join(repo, 'LICENSE'))) {
  const lic = readFileSync(join(repo, 'LICENSE'), 'utf8');
  const mit = /^\s*MIT License/.test(lic) && lic.includes('Permission is hereby granted, free of charge') && lic.includes('THE SOFTWARE IS PROVIDED "AS IS"');
  const holder = /Copyright \(c\) .+/.exec(lic)?.[0];
  if (mit && holder) pass('LICENSE is MIT', holder);
  else fail('LICENSE is MIT', mit ? 'no copyright line' : 'not the MIT text');
}

// screenshots
const shotsDir = join(repo, 'screenshots');
if (existsSync(shotsDir)) {
  const names = readdirSync(shotsDir).filter((n) => !n.startsWith('.')).sort();
  const images = [];
  for (const name of names) {
    const p = join(shotsDir, name);
    if (!statSync(p).isFile()) { fail('screenshot', `${name} is not a file`); continue; }
    const b = readFileSync(p);
    const size = imageSize(b);
    const extOk = size && ((size.type === 'png' && /\.png$/i.test(name)) || (size.type === 'jpeg' && /\.jpe?g$/i.test(name)));
    if (!size) fail('screenshot type', `${name} is neither PNG nor JPEG`);
    else if (!extOk) warn('screenshot type', `${name}: ${size.type} bytes under another extension`);
    if (b.length > CAPS.screenshots.max_bytes) fail('screenshot size', `${name} is ${b.length} bytes > ${CAPS.screenshots.max_bytes}`);
    if (!IMAGE_NAME.test(name)) fail('screenshot name', `${name} breaks the dossier name rule`);
    if (size) images.push(`${name} ${size.w}x${size.h} ${b.length}B`);
    if (size && (size.w < 1000 || size.h < 600)) warn('screenshot resolution', `${name} is ${size.w}x${size.h}`);
  }
  if (names.length < 3 || names.length > 4) fail('screenshot count', `${names.length} files, need 3 or 4`);
  else pass('screenshots', `${names.length}: ${images.join('; ')}; cover = ${names[0]}`);
  if (existsSync(join(repo, 'shots.json'))) {
    try {
      const listed = JSON.parse(readFileSync(join(repo, 'shots.json'), 'utf8')).map((s) => s.name).sort();
      if (listed.join() !== names.join()) warn('shots.json', `lists ${listed.join(', ')} but screenshots/ holds ${names.join(', ')}`);
    } catch (err) { warn('shots.json', `unreadable: ${err.message}`); }
  }
}

// game tree, caps and sizes
let tree = null;
try {
  tree = kit.readGameTree(gameDir, CAPS);
  const by = (cls) => tree.files.filter((f) => f.cls === cls);
  const sum = (list) => list.reduce((n, f) => n + f.bytes, 0);
  pass('game tree', `${tree.count} entries (${tree.files.length} files), ${tree.totalBytes} bytes; source ${by('source').length} (${sum(by('source'))} B), vendored ${by('vendored').length}, assets ${by('asset').length}`);
  const html = tree.files.find((f) => f.path === 'index.html');
  if (!html) fail('game/index.html', 'missing');
  else if (html.bytes > kit.INDEX_HTML_MAX_BYTES) fail('game/index.html', `${html.bytes} bytes > 1 MiB`);
  const assets = by('asset').map((f) => f.path);
  if (assets.length) warn('game assets', `non-source files (images/sounds are allowed but must be original): ${assets.slice(0, 8).join(', ')}`);
} catch (err) {
  fail('game tree', err.message);
}

// network and outside-reference scan
if (tree) {
  const files = new Set(tree.files.map((f) => f.path));
  const exists = (p) => files.has(p);
  const problems = [];
  const refs = [];
  for (const f of tree.files) {
    const text = readFileSync(join(gameDir, f.path), 'utf8');
    if (/\.(m?js)$/i.test(f.path)) {
      scanJs(text, f.path, problems);
      for (const spec of kit.sourceImports(text)) {
        refs.push(spec);
        const target = kit.isRelativeSpecifier(spec) ? kit.resolveGamePath(spec, f.path) : null;
        if (target === null || !exists(target)) problems.push(`${f.path}: import '${spec}' is not a file of game/`);
      }
    } else if (/\.html?$/i.test(f.path)) {
      const facts = kit.htmlFacts(text);
      const attrRefs = [...facts.scripts.map((s) => s.src).filter((s) => s !== null), ...facts.links.map((l) => l.href), ...facts.resources.map((r) => r.src)];
      for (const ref of attrRefs) {
        refs.push(ref);
        if (ref.startsWith('data:')) continue;
        const target = kit.resolveGamePath(ref, f.path);
        if (target === null || !exists(target)) problems.push(`${f.path}: reference '${ref}' is not a file of game/`);
      }
      for (const s of facts.scripts) if (s.src === null && s.text) scanJs(s.text, `${f.path} inline script`, problems);
      for (const m of text.matchAll(/\b(?:src|href|action|poster|srcset|data|formaction)\s*=\s*["']?\s*((?:[a-z]+:)?\/\/[^"'\s>]*)/gi)) problems.push(`${f.path}:${lineOf(text, m.index)} absolute URL ${m[1]}`);
      if (/<meta[^>]+http-equiv\s*=\s*["']?refresh/i.test(text)) problems.push(`${f.path}: meta refresh`);
      if (/<base\b/i.test(text)) problems.push(`${f.path}: <base> tag`);
      for (const m of text.matchAll(/<style[^>]*>([\s\S]*?)<\/style>/gi)) scanCss(m[1], `${f.path} <style>`, problems, f.path, exists, kit);
    } else if (/\.css$/i.test(f.path)) {
      scanCss(text, f.path, problems, f.path, exists, kit);
    }
  }
  if (problems.length) fail('no network / no outside files', problems.join('\n      '));
  else pass('no network / no outside files', `${refs.length} imports and page references, all relative files of game/`);
  const jsText = tree.files.filter((f) => /\.m?js$/.test(f.path)).map((f) => readFileSync(join(gameDir, f.path), 'utf8')).join('\n');
  const keyboard = /addEventListener\(\s*['"]key(down|up)['"]/.test(jsText);
  const mouse = /addEventListener\(\s*['"](pointer(down|up)|mouse(down|up)|click)['"]/.test(jsText);
  if (keyboard && mouse) pass('keyboard and mouse listeners', 'keydown and pointer/mouse listeners found');
  else fail('keyboard and mouse listeners', `keyboard ${keyboard}, mouse ${mouse}`);
}

// every module parses and links (named imports exist)
if (tree) {
  const mods = tree.files.filter((f) => /\.m?js$/.test(f.path)).map((f) => f.path);
  const syntax = [];
  for (const p of mods) {
    const r = spawnSync(process.execPath, ['--check', join(gameDir, p)], { encoding: 'utf8' });
    if (r.status !== 0) syntax.push(`${p}: ${(r.stderr.split('\n').find((l) => /Error/.test(l)) ?? r.stderr).trim()}`);
  }
  const linkErr = [];
  const domOnly = [];
  const exportsOf = new Map();
  for (const p of mods) {
    try {
      exportsOf.set(p, Object.keys(await import(pathToFileURL(join(gameDir, p)).href)));
    } catch (err) {
      if (err instanceof SyntaxError) linkErr.push(`${p}: ${err.message}`);
      else domOnly.push(p);
    }
  }
  // Modules Node cannot run (they touch the DOM at load): check their named imports against the exports.
  for (const p of domOnly) {
    const code = stripComments(readFileSync(join(gameDir, p), 'utf8'));
    for (const m of code.matchAll(/import\s*\{([^}]*)\}\s*from\s*['"]([^'"]+)['"]/g)) {
      const target = kit.resolveGamePath(m[2], p);
      const have = exportsOf.get(target);
      if (!have) continue;
      for (const name of m[1].split(',').map((s) => s.trim().split(/\s+as\s+/)[0]).filter(Boolean)) {
        if (!have.includes(name)) linkErr.push(`${p}: imports ${name} from ${m[2]}, which does not export it`);
      }
    }
  }
  if (syntax.length || linkErr.length) fail('modules parse and link', [...syntax, ...linkErr].join('\n      '));
  else pass('modules parse and link', `${mods.length} modules; DOM-only (checked statically): ${domOnly.join(', ') || 'none'}`);
}

// main.ts end to end, then the dossier
const out = mkdtempSync(join(tmpdir(), 'qa-out-'));
const run = spawnSync(process.execPath, [join(repo, 'main.ts')], { cwd: repo, env: { ...process.env, MAKEFUN_OUTPUT_DIR: out }, encoding: 'utf8', timeout: 120000 });
if (run.status !== 0) {
  fail('node main.ts', `exit ${run.status}: ${(run.stderr || run.stdout).trim().split('\n').slice(0, 6).join(' | ')}`);
} else {
  pass('node main.ts', `MAKEFUN_OUTPUT_DIR=${out}${run.stderr.trim() ? ` (stderr: ${run.stderr.trim().split('\n')[0]})` : ''}`);
  const dossierPath = join(out, 'dossier.json');
  if (!existsSync(dossierPath)) fail('dossier.json', 'not written');
  else {
    const raw = readFileSync(dossierPath);
    let doc = null;
    try { doc = JSON.parse(raw.toString('utf8')); } catch (err) { fail('dossier.json parses', err.message); }
    if (doc) {
      const textBytes = Buffer.byteLength(doc.text ?? '', 'utf8');
      const cut = /\[Cut at \d+ bytes: (\d+) files? and (\d+) bytes of source left out\.\]/.exec(doc.text ?? '');
      if (doc.schema !== 'makefun/dossier/v1') fail('dossier schema', `schema ${doc.schema}`);
      else if (doc.cover !== 0 || !Array.isArray(doc.images) || doc.images.length < 3 || doc.images.length > 4) fail('dossier schema', `cover ${doc.cover}, ${doc.images?.length} images`);
      else if (textBytes > CAPS.text_max_bytes) fail('dossier schema', `text ${textBytes} bytes > cap`);
      else pass('dossier schema', `makefun/dossier/v1, ${doc.images.length} images, text ${textBytes} B${cut ? `, CUT: ${cut[1]} files + ${cut[2]} B not shown` : ', no cut'}, ${raw.length} B total`);
      for (const img of doc.images ?? []) {
        const b = Buffer.from(img.base64 ?? '', 'base64');
        const onDisk = existsSync(join(shotsDir, img.name)) ? readFileSync(join(shotsDir, img.name)) : null;
        if (sha(b) !== img.sha256 || !onDisk || sha(onDisk) !== img.sha256) fail('dossier image', `${img.name} does not match screenshots/`);
      }
      try {
        const again = Buffer.from(kit.buildDossier(out, CAPS));
        if (again.equals(raw)) pass('dossier reproducible', 'buildDossier on the output dir writes the same bytes');
        else fail('dossier reproducible', 'buildDossier on the output dir writes different bytes than main.ts');
      } catch (err) { fail('dossier reproducible', err.message); }
    }
  }
  const copied = (sub) => existsSync(join(out, sub)) ? walk(join(out, sub)).sort() : [];
  for (const sub of ['game', 'screenshots']) {
    const src = existsSync(join(repo, sub)) ? walk(join(repo, sub)).sort() : [];
    const dst = copied(sub);
    const same = src.length === dst.length && src.every((p, i) => p === dst[i] && sha(readFileSync(join(repo, sub, p))) === sha(readFileSync(join(out, sub, p))));
    if (same) pass(`output ${sub}/ copy`, `${dst.length} files identical`);
    else fail(`output ${sub}/ copy`, `repo ${src.length} files vs output ${dst.length}`);
  }
  const entries = countEntries(out);
  if (entries > 1000) fail('output entries', `${entries} > 1000`);
  else pass('output entries', `${entries} of 1000; top level: ${readdirSync(out).join(', ')}`);
}
if (args.includes('--keep')) console.log(`kept ${out}`);
else rmSync(out, { recursive: true, force: true });
report();

function report() {
  console.log(`compliance ${repo}`);
  for (const r of results) console.log(`${r.level.padEnd(4)}  ${r.name}${r.detail ? `: ${r.detail}` : ''}`);
  const fails = results.filter((r) => r.level === 'FAIL').length;
  console.log(`${fails ? 'FAILED' : 'PASSED'}: ${results.length} checks, ${fails} failures, ${results.filter((r) => r.level === 'WARN').length} warnings`);
  process.exit(fails ? 1 : 0);
}
