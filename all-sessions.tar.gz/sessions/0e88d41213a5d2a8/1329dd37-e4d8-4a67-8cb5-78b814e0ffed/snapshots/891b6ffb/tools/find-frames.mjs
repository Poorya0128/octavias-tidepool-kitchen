// Screenshot frame search for Octavia's Tidepool Kitchen (Node 22, imports the game modules).
// Replays each service scene exactly like game/src/shots.js (same campaign path through
// playCampaign, same BUYS, same seed from shots.json), scores every frame of the night for
// every chef style in a small grid, and prints the best frame. --write stores the winners in
// the PLAYS table of shots.js.
//   node find-frames.mjs [--write] [--scene cover|moon|critic] [--seed n]

import { readFileSync, writeFileSync } from 'node:fs';

const REPO = '/projects/sandbox/octavias-tidepool-kitchen';
const SRC = `${REPO}/game/src/`;
const { LAYOUT, STEP } = await import(SRC + 'config.js');
const { createNight, stepNight } = await import(SRC + 'state.js');
const { createAutoChef, chefThink, playCampaign } = await import(SRC + 'autochef.js');
const { missingParts, ticketForPlate } = await import(SRC + 'orders.js');
const { streakMultiplier } = await import(SRC + 'scoring.js');

const args = process.argv.slice(2);
const flag = (name) => { const i = args.indexOf(name); return i >= 0 ? args[i + 1] : null; };
const WRITE = args.includes('--write');

const SHOTS = SRC + 'shots.js';
const shotsText = readFileSync(SHOTS, 'utf8');
/** Evaluates one `const NAME = {...};` literal of shots.js. */
function literal(name) {
  const m = shotsText.match(new RegExp(`const ${name} = (\\{[\\s\\S]*?\\});\\n`));
  if (!m) throw new Error(`shots.js has no const ${name}`);
  return Function(`return (${m[1]});`)();
}
const BUYS = literal('BUYS');
const PLAYS = literal('PLAYS');
const SEEDS = Object.fromEntries(JSON.parse(readFileSync(`${REPO}/shots.json`, 'utf8'))
  .map((s) => [s.query.match(/scene=(\w+)/)?.[1], Number(s.query.match(/seed=(\d+)/)?.[1] ?? 7)]));

/** Scene-specific musts (on top of the shared ones) and bonuses. */
const WANTS = {
  cover: {
    must: (s, front) => s.rush.active && ['shelby', 'puffy'].includes(front.customerId),
    bonus: () => 0,
  },
  moon: {
    must: (s, front) => front.customerId === 'twins',
    bonus: (s) => (s.tickets.filter((t) => t.customerId === 'twins').length >= 2 ? 1 : 0),
  },
  critic: {
    must: (s) => s.tickets.slice(0, LAYOUT.ticket.max).some((t) => t.critic),
    bonus: (s) => (s.plate.recipeId === 'platter' ? 6 : 0) + (s.pass.some((p) => p.recipeId === 'platter') ? 4 : 0),
  },
};

const CADENCES = [0.35, 0.4, 0.45, 0.5, 0.55, 0.6, 0.65];
const SERVE_AFTER = [0, 1, 2, 3, 3.5, 4, 5];
const FOCUS = [2, 3];

/** Station items that are not burnt, over every unlocked station. */
function cookingItems(s) {
  return Object.values(s.stations).filter((st) => !st.locked).flatMap((st) => st.slots).filter(Boolean);
}

/** null when a frame misses a must; otherwise its score (higher looks busier and clearer). */
function scoreFrame(s, want) {
  const left = s.cfg.duration - s.time;
  if (left < 35 || left > 145 || s.ink.active || s.ink.meter < 0.3 || s.ink.meter > 0.95) return null;
  if (s.tickets.length < 5 || !s.pass.length) return null;
  const front = ticketForPlate(s, s.pass[0]);
  if (!front) return null;
  const plate = s.plate;
  if (!plate.recipeId || plate.parts.length < 2 || !missingParts(plate.recipeId, plate.parts).length) return null;
  const items = cookingItems(s);
  const live = items.filter((i) => i.phase !== 'burnt');
  const perfect = live.filter((i) => i.phase === 'perfect').length;
  if (live.length < 3 || perfect < 1) return null;
  if (!want.must(s, front)) return null;
  const seated = new Set(s.tickets.map((t) => t.id));
  const talking = s.speech.some((sp) => s.time - sp.at < 2.5 && seated.has(sp.ticketId));
  const recentServe = s.time - (s.moments.serve ?? -99) < 1.2;
  const sourToasts = s.toasts.filter((t) => !/Shelby|Twin|bonus/i.test(t.text)).length;
  const strays = s.pass.filter((p) => !ticketForPlate(s, p)).length;
  const holding = s.arms.filter((a) => a.state === 'hold').length;
  return 2 * perfect + live.length - 4 * (items.length - live.length) + Math.min(s.tickets.length, 6)
    + plate.parts.length + s.pass.length - 3 * strays + 0.5 * Math.min(holding, 4) + 2 * s.ink.meter
    + (talking ? 2 : 0) + (recentServe ? 1.5 : 0) + (streakMultiplier(s.streak) > 1 ? 1 : 0)
    - 1.5 * sourToasts + want.bonus(s);
}

/** A short description of the frozen frame, for the report. */
function describe(s) {
  const left = s.cfg.duration - s.time;
  const clock = `${Math.floor(left / 60)}:${String(Math.floor(left % 60)).padStart(2, '0')}`;
  const front = ticketForPlate(s, s.pass[0]);
  const items = cookingItems(s).map((i) => `${i.ing}:${i.phase}`).join(' ');
  return `clock ${clock} left, ${s.tickets.length} tickets [${s.tickets.map((t) => t.customerId).join(' ')}], `
    + `plate ${s.plate.recipeId} ${s.plate.parts.length} parts, window [${s.pass.map((p) => p.recipeId).join(' ')}] front for ${front.customerId}, `
    + `stations ${items}, ink ${s.ink.meter.toFixed(2)} (${s.ink.uses} bursts), streak ${s.streak} x${streakMultiplier(s.streak)}, rush ${s.rush.active}`;
}

/** Best frame of one night for one chef style: { frames, score, text } or null. */
function searchNight(nightIndex, upgrades, seed, chefOpts, want) {
  const s = createNight({ nightIndex, upgrades, seed });
  const chef = createAutoChef(chefOpts);
  let best = null;
  for (let f = 1; !s.over && s.time < s.cfg.duration - 34; f++) {
    chefThink(s, chef, STEP);
    stepNight(s, STEP);
    s.events.length = 0;
    const score = scoreFrame(s, want);
    if (score !== null && (!best || score > best.score)) best = { frames: f, score, text: describe(s) };
  }
  return best;
}

const only = flag('--scene');
const results = {};
for (const [name, play] of Object.entries(PLAYS)) {
  if (only && name !== only) continue;
  const seed = Number(flag('--seed') ?? SEEDS[name] ?? 7);
  const { upgrades } = playCampaign(play.night, seed, BUYS);
  let best = null;
  let valid = 0;
  for (const cadence of CADENCES) for (const serveAfter of SERVE_AFTER) for (const focus of FOCUS) {
    const chef = { cadence, serveAfter, focus };
    const found = searchNight(play.night, upgrades, seed, chef, WANTS[name]);
    if (!found) continue;
    valid++;
    if (!best || found.score > best.score) best = { ...found, chef };
  }
  console.log(`${name} (night ${play.night}, seed ${seed}, upgrades ${Object.keys(upgrades).join(',')}): ${valid}/${CADENCES.length * SERVE_AFTER.length * FOCUS.length} chef styles have a valid frame`);
  if (!best) { console.log('  no valid frame'); continue; }
  console.log(`  best frames ${best.frames} chef ${JSON.stringify(best.chef)} score ${best.score.toFixed(1)}\n  ${best.text}`);
  results[name] = best;
}

if (WRITE && Object.keys(results).length) {
  const lines = Object.entries(PLAYS).map(([name, play]) => {
    const r = results[name];
    const frames = r ? r.frames : play.frames;
    const chef = r ? r.chef : play.chef;
    const chefText = Object.entries(chef).map(([k, v]) => `${k}: ${v}`).join(', ');
    return `  ${name}: { night: ${play.night}, frames: ${frames}, chef: { ${chefText} } },`;
  });
  const table = `const PLAYS = {\n${lines.join('\n')}\n};\n`;
  writeFileSync(SHOTS, shotsText.replace(/const PLAYS = \{[\s\S]*?\};\n/, table));
  console.log('shots.js PLAYS updated');
}
